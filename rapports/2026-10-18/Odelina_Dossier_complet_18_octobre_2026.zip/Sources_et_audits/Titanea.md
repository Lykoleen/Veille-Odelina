# Titanea — audit éditorial et UX pour Odelina

Observation : **18 octobre 2026**. Pages publiques consultées ; aucune inscription, aucun achat, aucun envoi de formulaire. Les descriptions ci-dessous sont reformulées. Les prix et états de stock sont des observations ponctuelles.

## Lecture générale

**Titanea associe une boutique classée par emplacement à une forte argumentation matière et à des pages pédagogiques très développées.** Le meilleur apport pour Odelina est la proximité entre aide au choix et produit. Sa faiblesse la plus utile à étudier est l'accumulation d'explications et de règles présentées comme universelles, parfois contradictoires : profondeur de contenu ne signifie pas automatiquement fiabilité ou simplicité.

Odelina a intérêt à conserver une autre promesse : **aider à créer une composition que l'on comprend, que l'on peut adapter et que l'on peut acheter avec confiance.** Les pages de référence doivent servir les sets et le Composer, sans créer un blog ou un forum pour reproduire la stratégie Titanea.

## Périmètre et preuves

| ID | Page observée | URL exacte | Preuve locale |
|---|---|---|---|
| T01 | Accueil | https://titanea.fr/ | home.html, home.txt, home-desktop.png, home-mobile.png |
| T02 | Guide des tailles | https://titanea.fr/guide-des-tailles-des-piercings/ | guide.html, guide.txt, guide-desktop.png, guide-mobile.png |
| T03 | FAQ | https://titanea.fr/faq/ | faq.html, faq.txt |
| T04 | Collection hélix | https://titanea.fr/piercing-helix-titane/ | helix.html, helix.txt |
| T05 | Collection oreille | https://titanea.fr/piercing-oreille-titane/ | oreille.html, oreille.txt |
| T06 | Fiche Le Simple | https://titanea.fr/piercing-en-titane/le-simple/ | simple.html, simple.txt, simple-desktop.png, simple-mobile.png, options-desktop.json |
| T07 | Fiche La Cascade Précieuse | https://titanea.fr/piercing-en-titane/la-cascade-precieuse/ | product.html, product.txt |
| T08 | Nettoyage du piercing en titane | https://titanea.fr/comment-nettoyer-un-piercing-en-titane-le-guide-complet/ | clean.html, clean.txt |
| T09 | Nettoyage du piercing d'oreille et du bijou | https://titanea.fr/piercing-doreille-guide-nettoyage-entretien/ | oldcare.html, oldcare.txt |
| T10 | Inspiration compositions | https://titanea.fr/composition-piercing-oreille-le-top-5-des-curated-ear-2026/ | curated.html, curated.txt |
| T11 | Matière : titane ou acier | https://titanea.fr/titane-ou-acier-chirurgical-piercing/ | material.html, material.txt |
| T12 | À propos | https://titanea.fr/a-propos/ | about.html, about.txt |
| T13 | Index des articles | https://titanea.fr/blog/ | blog.html, blog.txt |

Toutes les pages ci-dessus ont répondu HTTP 200 lors de l'observation. Textes récupérés par urllib avec vérification TLS. Rendu Chromium observé sur accueil, guide et fiche Le Simple, en 1440 × 1080 et 390 × 844. Les captures longues ne prouvent pas le comportement d'un élément fixe dans toutes les situations de défilement. Certaines images de recommandations ne sont pas chargées dans une capture desktop ; ce point n'est pas qualifié comme défaut du site.

## 1. Guide des tailles : beaucoup de réponses, encore trop d'assurance

### Preuves

- **T02** explique le format épaisseur × longueur ou diamètre, distingue tige utile et embouts, précise que le diamètre de l'anneau est intérieur. C'est une bonne réponse à une difficulté de commande concrète.
- Le guide donne une correspondance gauge/millimètres, une méthode au pied à coulisse et un parcours par zone, puis un tableau récapitulatif et des explications de fermetures. Il conseille de ne mesurer un bijou retiré que si le piercing est cicatrisé et renvoie au perceur en cas de doute.
- Un sommaire ancré de **18 entrées** aide à retrouver l'information. Les sections courtes commencent souvent par une réponse immédiatement exploitable.
- La page comporte trois illustrations techniques des fermetures, avec légende et texte alternatif : vissage interne, push-in et clicker. Dans le contenu audité, la lecture des dimensions et les étapes de mesure sont surtout expliquées par le texte et les tableaux ; les trois schémas spécifiques portent sur les fermetures.
- Elle ne se limite pas à l'oreille : nez, bouche, langue, nombril et téton prolongent la page.

### Faiblesses vérifiées

- **T02, même page :** la section nombril propose 10 mm comme taille définitive, avec 8 mm pour un petit nombril ; le tableau final présente 8 mm après la pose comme ligne générale. Un lecteur utilisant le raccourci du tableau obtient une autre règle que celui lisant la section.
- **T02, même page :** la section daith indique 8 ou 10 mm comme tailles usuelles, alors que la ligne du tableau regroupant conch-barre et daith-anneau indique 10 à 12 mm. Ce regroupement mêle aussi longueur de barre et diamètre d'anneau.
- **T02 vs T04 :** 41 % des ventes hélix en 1,2 × 8 mm dans le guide ; 37 % dans la collection hélix (avec 1 008 / 2 722 et octobre 2026). Les périmètres et périodes ne permettent pas de réconcilier ces chiffres ; ce sont des données déclarées par le marchand, non auditées.
- Le guide recommande une dimension pour offrir un bijou sans connaître la taille de la personne. Cette commodité commerciale peut donner l'impression qu'une taille populaire est une taille adaptée.
- Des calendriers et dimensions de première pose/downsize sont formulés de façon prescriptive. Le guide démarre sur l'idée de deux épaisseurs qui suffiraient à éviter l'erreur, mais traite ensuite d'importantes différences anatomiques et d'autres épaisseurs. La nuance arrive après une promesse trop simple.

### Interprétation pour Odelina

La valeur vient de l'explication de la **mesure à vérifier**, pas du nombre de tailles alignées. Faire commencer le futur guide par trois choix : « je connais mes mesures », « je veux mesurer mon bijou », « je ne sais pas ». Dans le Composer, conserver la zone sélectionnée, ouvrir une aide courte sur la bonne mesure, puis revenir à la même composition. Ne pas choisir une taille automatiquement sur la seule base de l'emplacement.

## 2. Emplacements : une navigation utile, mais dispersée entre commerce et éditorial

### Preuves

- **T01 :** le menu Boutique répartit l'offre par oreille, nez, bouche et corps ; sous l'oreille, on retrouve notamment conch, daith, hélix, anti-hélix, industriel, rook et tragus.
- **T05 :** la collection oreille nomme 12 zones principales et décrit des familles anatomiques ; chaque entrée renvoie quand possible vers une collection de produits.
- **T04 :** la collection hélix explique différences entre hélix, anti-hélix et flat, dimensions, cheveux, sommeil, choix labret/anneau, composition double/triple hélix et soin. Le haut reste une grille commerciale avec filtres couleur, budget et tri ; une grande partie de la pédagogie vient après les 24 produits de la première page.
- **T06 :** la fiche Le Simple associe le même anneau à onze emplacements recommandés, ainsi qu'à neuf variantes de tailles. La compatibilité est présentée globalement au niveau du modèle ; les mesures des variantes doivent encore être mises en relation avec la personne.

### Interprétation

Titanea propose de nombreuses portes d'entrée, mais il faut changer de page pour passer de la définition d'une zone à sa taille et à ses bijoux. La quantité de texte après une grande grille est plus favorable à une lecture approfondie qu'à une décision rapide.

Pour Odelina, une **carte d'oreille interactive avec équivalent accessible en liste** peut réunir nom courant, localisation, familles de bijoux, critères de taille et contraintes d'usage. Une fois la zone comprise, le bouton principal peut être « Ajouter cet emplacement à ma composition ». La carte doit accepter une oreille différente du modèle et rappeler que l'anatomie se confirme auprès d'un professionnel ; elle n'est pas une validation de faisabilité de perçage.

## 3. Entretien : distinguer impérativement le bijou et le piercing

### Preuves

- **T08 :** le guide de nettoyage distingue étapes, produits, erreurs, spécificités par zone et FAQ ; il ne conseille pas de tourner le bijou.
- **T09 :** la page sépare explicitement un passage consacré au piercing et un autre consacré au bijou retiré, avec un tableau par matière. Cette séparation est une bonne structure éditoriale.
- **T06-T07 :** les fiches précisent la finition, la matière et la fermeture. Le Simple indique un revêtement PVD pour les couleurs ; La Cascade Précieuse indique anodisation. C'est plus utile pour préparer un entretien adapté qu'une promesse uniforme sur tout le catalogue.

### Limites et affirmations à ne pas reproduire sans vérification spécialisée

- **T08 vs T09 :** les recettes de solution saline maison diffèrent : un quart de cuillère à café pour 240 ml dans le guide titane, une demi-cuillère pour une tasse dans le guide oreille. Le deuxième passage place cette recette à côté de la solution stérile ; or une préparation maison n'est pas une solution stérile contrôlée. Ne pas reprendre ces recettes dans les textes Odelina.
- **T08 :** une reprise piscine/mer après 4 à 6 semaines avec pansement est présentée comme règle ; elle demanderait une validation professionnelle adaptée à la zone et à la cicatrisation.
- **T04 :** un « test » suggère de tirer doucement le piercing dans plusieurs sens avant de passer à un anneau. Ne pas transposer cette manipulation dans une page de conseil Odelina.
- **T09 :** des formules assimilent le titane à une matière tolérant tout et prétendent qu'un passage au titane résout définitivement certaines irritations. Elles sous-estiment la finition, les pierres, les dépôts, les contraintes mécaniques et les autres causes possibles. Odelina doit expliquer la matière exacte et ses limites, sans promesse médicale.
- **T10 :** « zéro réaction allergique » est une formulation absolue. **T11** mentionne au contraire une allergie très rare ; une même marque ne devrait pas alterner garantie absolue et risque résiduel.
- Les pages possèdent une forte voix d'expert et citent l'APP, mais les recommandations commerciales ne constituent pas des avis médicaux indépendants.

### Interprétation pour Odelina

Créer une **page permanente « Entretenir mes bijoux »**, pas une nouvelle rubrique d'articles. Premier choix : « nettoyer mon bijou retiré » / « mon piercing est en cours de cicatrisation ». Le premier parcours peut donner une méthode validée pour les matières et finitions réellement vendues. Le second doit expliquer les limites du guide, orienter vers les consignes du perceur et le professionnel de santé en cas de symptômes préoccupants. Vérifier l'usage des produits avec les fournisseurs ; ne pas supposer qu'une tolérance du métal s'étend aux pierres, colles, dorures ou autres finitions.

## 4. Qualité des textes et pédagogie matière

### Ce qui fonctionne

- **T06-T07 :** les premières descriptions parlent de forme, mouvement, rendu et usage avant les spécifications. La Cascade Précieuse explique le mouvement indépendant des zircons et réserve le modèle à un piercing cicatrisé ; l'information est liée au design précis.
- Les fiches structurent les caractéristiques : matière/certification déclarée, finition, fermeture, pierres s'il y en a, unité de vente et emplacements. Cette logique réduit les descriptions vagues.
- **T01-T11 :** le positionnement tout titane est cohérent et récurrent ; il donne une raison identifiable de choisir la marque.

### Ce qui peut nuire à la confiance

- **T06 :** le sélecteur affiche des couples de mesures sans distinguer graphiquement épaisseur et diamètre intérieur. Dans la description, les anneaux sont même décrits avec des « longueurs » de 5 à 12 mm alors que le guide explique le diamètre intérieur : incohérence de vocabulaire sur la décision la plus importante.
- **T01-T11-T12 :** les comparaisons matière recourent à des oppositions très appuyées, à des généralisations sur l'acier et à des promesses santé. L'article matière présente le poids et le prix comme indices de reconnaissance du titane ; ils ne remplacent pas une traçabilité documentaire.
- Le terme G23 est rapproché à plusieurs endroits de la certification ASTM F136 sans que l'audit ait pu vérifier les certificats de chaque lot. **Constat sur les textes déclaratifs uniquement**, pas évaluation laboratoire des bijoux.
- Le volume d'articles multiplie les endroits où une règle doit être maintenue. Les contradictions de tailles et recettes montrent le coût d'entretien d'une bibliothèque très étendue.

### Ligne éditoriale transposable

Pour chaque bijou Odelina : une phrase de style concrète, une phrase d'usage dans une composition, puis des caractéristiques vérifiables. Pour la matière : nom de l'alliage, norme documentée si disponible, finition, limites d'usage et preuve consultable. Éviter « adapté à toutes », « sans risque », « taille universelle », « ne s'abîme jamais ». Centraliser les données techniques qui alimentent les fiches, guides et Composer.

## 5. Parcours produit, dimensions et panier

### Ce qui a été vu dans Chromium

- **T06 desktop :** visuel produit principal et miniatures d'un côté ; titre, prix, phrase d'usage, couleur, taille et ajout au panier de l'autre. Palette ivoire/noir, accents cuivrés, titrage serif, texte de lecture sans serif. La hiérarchie calme rend les options repérables.
- Le lien « Guide des tailles » est juste à côté du libellé Taille : très bon emplacement pour une aide contextuelle. Le HTML indique une ouverture dans un nouvel onglet (`target=_blank`), plutôt qu'une aide intégrée à la fiche.
- Une couleur dorée est sélectionnée dans la capture initiale ; aucune taille n'est sélectionnée, et le bouton d'ajout apparaît grisé. Le sélecteur distingue une variante épuisée dans son libellé. Une sélection locale ultérieure Dorée + 1,2 × 8 mm affiche « En stock » et active visuellement l'ajout (selection-desktop.png, rendu via requêtes TLS vérifiées). Aucun ajout n'a été envoyé.
- Une preuve d'avis boutique est placée au-dessus du titre ; elle est libellée comme note boutique, distincte des deux avis du produit.
- Les caractéristiques sont accessibles dans une barre d'onglets avec Description, Guides et Avis ; l'onglet Caractéristiques est visible par défaut dans les captures.
- **Mobile 390 px :** galerie d'abord, bloc d'achat en dessous, puis tableau de caractéristiques et suggestions en deux colonnes. Un bouton fixe « Choisir les options » est visible. Son comportement complet au défilement n'a pas été validé. Le tableau empile les intitulés et contenus sur petit écran, ce qui évite un tableau trop large mais allonge la page.

### Ce qui n'est pas établi

Aucun paiement ni ajout au panier n'a été envoyé. La continuité exacte entre le guide et un choix de variante, la conservation du choix après retour, les messages d'erreur et la validation de panier n'ont pas été entièrement testés. Les tentatives d'interaction natives supplémentaires ont rencontré la chaîne de certificats du navigateur ; le contenu HTML a pu être récupéré avec TLS vérifié et rendu par une route réseau vérifiée séparément pour des vérifications locales. Aucun contournement de certificat.

### Interprétation pour Odelina

Une aide à côté de l'option est plus utile qu'un guide uniquement dans le pied de page. Dans un set, afficher la dimension de **chaque pièce**, le nombre de bijoux et les emplacements prévus avant le bouton d'ajout. Dans le Composer, la bonne étape est : zone → bijou → mesure à confirmer → ajout à la composition. Le panier doit conserver cette structure par composition, avec correction d'une seule pièce et retour au Composer.

## 6. Sets et composition : conserver l'avance d'Odelina

### Preuves

- **T10 :** l'article d'inspiration présente cinq styles de composition, un tableau avec nombre de piercings et emplacements types, puis une explication de l'équilibre visuel et de l'adaptation à l'anatomie.
- Il renvoie à des bijoux, des collections, au guide de taille et au perceur. Il propose un vocabulaire esthétique utile : point focal, dégradé, respiration, cohérence.
- Dans les menus, collections et fiches de l'échantillon, aucun outil interactif de composition comparable au Composer d'Odelina n'a été rencontré. Cela n'établit pas une absence exhaustive sur l'ensemble de Titanea.

### Interprétation

L'article donne des idées mais laisse le travail d'assemblage et de vérification au lecteur. **Odelina peut transformer l'inspiration en projet modifiable.** Chaque set devient une composition de départ dont on comprend l'équilibre, avec des rôles simples : pièce principale, rappel, liaison. Un bouton « Adapter ce set dans le Composer » conserve les bijoux et les zones ; une modification d'un bijou ne détruit pas le reste du projet. L'aide de taille explique une mesure, l'aide d'emplacement explique une zone, et aucune ne détourne de la composition en cours.

## Cinq enseignements à transposer sans copier

1. **Mettre l'aide au point de choix.** Depuis un set ou le Composer, ouvrir une aide dimensionnelle courte liée au type de bijou et à la zone ; conserver tous les choix au retour. Critère de réussite : l'utilisatrice peut expliquer épaisseur et diamètre/longueur avant d'ajouter la pièce.
2. **Une seule donnée technique, plusieurs usages.** Utiliser un modèle de données cohérent pour dimensions, finition, unité de vente et compatibilité ; les mêmes valeurs alimentent fiches, tableau du set, guide et panier. Critère : aucune contradiction entre la carte produit et le récapitulatif.
3. **Une carte d'emplacements orientée composition.** Associer chaque zone à une définition courte, un zoom illustré, des familles de bijoux et un retour au Composer. Critère : reconnaître la zone sans connaître le jargon, avec navigation clavier et liste textuelle.
4. **Un entretien pratique, selon l'objet et sa finition.** Une page de référence permanente distingue bijou retiré et piercing ; les instructions portent sur les matériaux réellement vendus et ont été validées. Critère : la lectrice comprend quoi nettoyer et quand demander conseil, sans faire de diagnostic.
5. **Vendre un équilibre expliqué.** Sur un set, dire en deux phrases pourquoi les pièces se répondent et ce qui peut être remplacé. Le CTA conduit à une adaptation déjà préremplie dans le Composer. Critère : l'utilisatrice peut changer une pièce ou un emplacement sans recommencer.

## Priorités proposées

- **P0 :** vocabulaire dimensions homogène ; caractéristiques par pièce du set ; aide à la mesure depuis le Composer ; limites explicites pour les tailles et conseils de santé.
- **P1 :** guide des emplacements relié à la composition ; page d'entretien par matière/finition ; retour au projet conservé depuis les guides.
- **P2 :** variantes de sets guidées par effet visuel, sauvegarde de projet si le fonctionnement réel le permet, et amélioration de l'aide mobile après tests d'usage.

## Limites de l'audit

Échantillon qualitatif, pas crawl complet ; pas de mesure de conversion, accessibilité exhaustive, performance terrain ou tests avec clientes. Pas de contrôle des certificats matière, des stocks ou des allégations médicales. Les critiques de prescriptions signalent des points à faire valider et à ne pas recopier, sans proposer de diagnostic ni de règle clinique de remplacement. Les préconisations Odelina sont des propositions de conception, distinctes des éléments observés chez Titanea.
