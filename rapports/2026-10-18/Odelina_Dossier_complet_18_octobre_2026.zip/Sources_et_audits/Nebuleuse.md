# Nébuleuse Bijoux — audit ciblé pour Odelina

Observation : **18 octobre 2026**. Site : <https://nebuleusebijoux.com/>. Lecture éditoriale de 11 pages pertinentes ; rendu réel Chromium à 1440 × 1000 et 390 × 844 pour six pages ; ouverture du guide des tailles sur ordinateur et mobile. Analyse sans compte, achat ni ajout au panier. Les prix, stocks, avis et nombres de produits sont des instantanés de l'observation.

## Lecture stratégique

Nébuleuse fait particulièrement bien le lien entre **désir visuel**, **choix du bijou** et **réassurance technique** : photographies de compositions portées, navigation par emplacement, caractéristiques structurées, aide de taille au voisinage du sélecteur et explication de sa fermeture Earfinity©. La marque rend son expertise tangible en nommant une créatrice et une perceuse expérimentée.

La principale occasion pour Odelina se situe **entre l'inspiration et l'adaptation personnelle**. Dans les pages de compositions inspectées, Nébuleuse propose des ensembles photographiés et listés, mais la fiche testée ne relie pas explicitement chaque pièce à un emplacement et à une mesure individuelle. Odelina peut faire de son Composer l'endroit où les guides deviennent immédiatement utiles : comprendre une zone, vérifier une dimension, adapter un set puis conserver ce contexte au panier.

Cette conclusion porte sur l'échantillon observé : elle n'établit pas l'absence d'un outil comparable dans tout le site Nébuleuse.

## 1. Constats vérifiés : contenu et pédagogie

### Une fiche technique réellement exploitable

**Preuve N1.** <https://nebuleusebijoux.com/products/andrea-titane> : le produit présente un décor de 4 × 6 mm, une barre de 7 mm, une épaisseur de 1,2 mm et les zones Hélix, Tragus, Conch et Flat. Les dimensions du décor, la longueur de barre et son épaisseur sont donc distinguées dans les spécificités. La compatibilité avec une première pose est affichée dans les réassurances près du bouton d'achat puis dans la fiche technique.

**Interprétation.** Cette séparation réduit une ambiguïté fréquente du mot « taille ». Elle donne matière à décider, au-delà d'un texte d'ambiance. Le sélecteur du haut affiche toutefois « Longueur de la barre : 7 », sans unité accolée au chiffre dans le rendu observé. Odelina gagnerait à écrire « Barre : 7 mm » partout, dès le choix.

**Preuve N2.** <https://nebuleusebijoux.com/products/anneau-leonie> : quatre tailles sont proposées, 6, 8, 10 et 12 mm ; la fiche précise l'épaisseur 1,2 mm et indique que ce modèle n'est pas adapté à une première pose. La description le situe après cicatrisation. Une FAQ explique séparément pourquoi les tiges droites sont généralement privilégiées au départ et pourquoi le diamètre du trou au lobe peut ne pas convenir à une tige 1,2 mm.

**Interprétation.** La fiche traite des hésitations concrètes d'une cliente. Le vocabulaire technique est relié à des situations d'usage, ce qui est plus pédagogique qu'une liste de matières seule.

### Un guide de taille accessible au bon endroit, mais incomplet pour mesurer

**Preuve N3.** Sur ces deux fiches, un lien « Guide des tailles » ouvre un tiroir. Le guide des anneaux, ouvert sur ordinateur et mobile, contient un schéma légendé de l'oreille et un tableau emplacement/diamètre. Exemples observés : Hélix 8/10 mm, Conch 10/12 mm, Lobe 8/10/12 mm. Le texte présente ces valeurs comme des tailles couramment utilisées par les perceurs.

Le guide des barres est distinct : son tableau emplacements/longueurs figure dans le contenu de la fiche Andrea. Le tiroir des anneaux inspecté ne définit pas « diamètre intérieur », ne montre pas de flèches de mesure sur un anneau et n'explique pas comment relever sa dimension. Aucun ajustement du tableau à l'anatomie de la cliente n'est proposé dans ce tiroir.

**Interprétation.** L'ouverture locale évite de quitter la fiche et le dessin associe immédiatement un nom à une zone. Le tableau aide à se repérer mais ne suffit pas à choisir entre deux valeurs pour son oreille. Le risque est de lire une fourchette générique comme une prescription individuelle. Pour Odelina, conserver l'aide contextuelle mais ajouter une vraie méthode de mesure et un rappel de la variation anatomique, sans automatiser une validation de première pose.

### Des emplacements expliqués, mais un article très large

**Preuve N4.** <https://nebuleusebijoux.com/blogs/blog/meilleurs-piercings-doreille-le-guide-et-notre-selection>, daté du 31 août 2026 et annoncé à 12 minutes : sections Lobe, Hélix, Tragus, Conch, Rook et Daith ; critères de choix, sélection commerciale, matières, formes, dimensions, déroulement d'un perçage, tarifs, cicatrisation et FAQ. Le texte relie par exemple le tragus aux frottements des écouteurs et le conch à l'équilibre d'une composition.

Le contenu précise à plusieurs endroits que le choix dépend de l'anatomie et du professionnel. Il ne se limite donc pas à un catalogue de zones. Les dimensions restent abordées de façon générale, sans tutoriel illustré de mesure.

**Interprétation.** L'intention pédagogique est solide mais la page cumule plusieurs intentions : se faire percer, acheter, comprendre une matière et imaginer une composition. Odelina peut répondre plus vite avec une page pérenne « Guide des emplacements », des fiches de zone courtes et un renvoi ciblé au Composer. Il n'est pas nécessaire de créer un blog, un forum ou un flux d'articles.

**Preuve N5.** Dans cet article, le lien textuel « piercing daith » pointe vers `piercing%20daith`, résolu en <https://nebuleusebijoux.com/blogs/blog/piercing%20daith> ; cette URL a répondu **404** lors du contrôle. Les autres zones principales observées renvoient à des collections adéquates.

**Interprétation.** La qualité de l'aide dépend aussi de sa maintenance. Un contrôle des liens et une source unique des noms de zones sont des améliorations simples à prévoir pour Odelina.

### Un entretien concret, chaleureux, mais des frontières à clarifier

**Preuve N6.** <https://nebuleusebijoux.com/blogs/blog/prendre-soin-de-ses-bijoux>, daté du 10 mars 2020 et annoncé à 4 minutes, traite du nettoyage, des cosmétiques, de la douche, du rangement, du sommeil et du sport. Les gestes sont précis : eau claire, brosse souple dédiée, séchage au chiffon, rangement séparé. Le détail consistant à fermer l'évacuation du lavabo avant de retirer un bijou est utile et mémorable. La page propose aussi des boîtes et trousses.

Le début inclut plusieurs matières — acier 304, titane ASTM-F136 et argent 925 plaqué or — puis l'entretien reste largement commun. La page parle de boucles et de piercings, conseille de retirer ses bijoux pour le sport ou avant le sommeil, et ne borne pas ces gestes au cas d'un bijou amovible sur piercing cicatrisé dans les passages concernés.

**Interprétation.** Le ton rend les conseils accessibles mais les nombreuses émoticônes et apartés ralentissent la recherche d'une réponse. Une page Odelina peut être plus courte, plus mature et plus opérationnelle : « après l'avoir porté », « nettoyer », « ranger », « à éviter », puis une distinction claire entre entretien du bijou retiré et suivi d'un piercing récent.

**Preuve N7.** Le lien de pied de page « Conseil post perçage », <https://nebuleusebijoux.com/pages/soins-apres-un-piercing>, redirige vers <https://nebuleusebijoux.com/products/reservation-piercing>. Cette dernière présente un bloc de sept conseils : nettoyage, éviter l'immersion, réactions possibles, ne pas manipuler, éviter les pressions, demander de l'aide et respecter la cicatrisation. La page mentionne explicitement un professionnel de santé pour certains signes d'infection.

**Interprétation.** Il existe donc une séparation de contenu sur le site, mais la redirection vers une page de réservation et la généralité de certains conseils d'entretien peuvent brouiller cette distinction. Odelina peut rendre les deux périmètres très explicites sans devenir un site médical.

### Expertise incarnée et répétition commerciale

**Preuve N8.** <https://nebuleusebijoux.com/pages/expertise> nomme Adélie, créatrice, et Maïté, perceuse depuis plus de dix ans. La page détaille le titane, la fermeture Earfinity et trois notions : création, exigence, transmission. Les fiches Andrea et Anneau Léonie expliquent aussi la norme ASTM-F136 et la biocompatibilité ; la fiche Andrea présente un tutoriel de fermeture.

**Interprétation.** Montrer un mécanisme, un geste et les personnes qui le maîtrisent apporte plus de valeur qu'une promesse abstraite. En revanche, les formulations sur la sécurité, la durabilité et la cicatrisation reviennent très souvent. Odelina devrait privilégier une donnée précise et une explication courte, puis un lien vers le détail.

## 2. Constats vérifiés : sets et parcours

**Preuve N9.** <https://nebuleusebijoux.com/collections/sets> présentait 46 compositions au contrôle. Les cartes affichent des photographies portées, le nom, le prix et deux finitions. La grille est immédiatement visuelle. Son introduction promet des ensembles prêts à l'emploi pour qui manque d'inspiration.

**Preuve N10.** <https://nebuleusebijoux.com/products/composition-lumineuse> affiche une composition à 124 €, deux finitions et un carrousel « Dans cette composition » listant Lumineuse (32 €), Délicate (29 €), Chaleureuse (16 €), Étoilée Titane (47 €). Le total des quatre prix affichés est égal au prix du set : aucune économie de lot ne peut être déduite de cet échantillon. Le rendu mobile laisse voir environ deux pièces à la fois, avec des flèches de défilement.

Dans cette fiche inspectée, les choix visibles portent sur la couleur et la quantité ; le contenu ne fournit pas de tableau « pièce → emplacement → dimension », ni de bouton visible d'adaptation du set par emplacement. Les avis et les accordéons entretien/livraison/retours complètent la page. L'ajout au panier n'a pas été déclenché.

**Interprétation.** L'inspiration et la transparence sur les pièces sont réussies. La cliente doit cependant encore déduire les trous nécessaires et la compatibilité avec ses bijoux déjà portés. C'est un espace de différenciation très cohérent pour Odelina : ne pas seulement montrer un bel ensemble, mais expliquer comment le rendre portable par cette personne.

## 3. Audit visuel réellement observé

- **Ordinateur, fiche Andrea.** Grande photographie sur fond clair à gauche ; colonne de choix à droite ; matière, résistance à l'eau, garantie et première pose présentées par pictogrammes ; lien de taille aligné avec le sélecteur ; bouton principal noir bien identifiable ; accordéons pour les contenus secondaires. Les caractéristiques complètes sont plus bas que le choix initial.
- **Mobile, fiche Andrea.** Galerie en défilement horizontal puis titre, prix et avis ; les variantes et l'aide de taille sont plus bas. Une barre fixe conserve couleur, dimension et bouton panier. Elle rapproche l'action mais la dimension y apparaît comme un simple chiffre, ce qui invite Odelina à garder unité et sens du choix même dans les formats compacts.
- **Tiroir de taille.** Il conserve le contexte de la fiche. Le schéma d'oreille puis le tableau sont lisibles sur 390 px. Le dessin explique les zones, pas la manière de mesurer le bijou. Fermeture par croix visible.
- **Compositions.** Les photographies de l'oreille portée expliquent l'effet final avant la lecture. Odelina peut reprendre le principe de preuve portée avec sa propre direction artistique et une annotation originale des pièces ; il ne faut pas reprendre la mise en page ou les photographies concurrentes.
- **Page entretien.** En-tête éditorial illustré puis colonne de texte avec grandes intertitres. La hiérarchie est lisible ; il n'y a pas de résumé pratique en tête dans la portion et le contenu inspectés. Le texte demande un défilement conséquent sur mobile.

Ces observations ne constituent pas une étude utilisateur, un audit complet d'accessibilité ou une mesure de conversion. Aucun chiffre de performance ou d'efficacité commerciale n'est déduit des captures.

## 4. Formulations à ne pas reprendre comme vérité

Les éléments suivants sont des **promesses du concurrent**, pas des conclusions médicales de cet audit :

1. Le guide entretien assimile l'absence de nickel à l'absence de risque d'allergie ou d'irritation pendant le sport. Cette formulation absolue ne doit pas être reprise par Odelina. Une composition déclarée ne prouve pas l'absence universelle de réaction.
2. Certaines FAQ produit emploient une formulation proche de « limite tout risque » d'irritation ; elle est plus forte que les formulations de réduction de risque présentes ailleurs. Préférer une explication factuelle et bornée.
3. L'entretien mélange des consignes de retrait de bijoux et des mentions de piercings ; la page post-perçage demande de ne pas retirer un bijou pendant la cicatrisation. Ce n'est pas nécessairement une contradiction si les publics sont différents, mais leur frontière n'est pas explicite partout.
4. L'article emplacements indique pour l'hélix une durée courante de 3 à 6 mois, puis rappelle pour les cartilages une durée professionnelle de 6 à 9 mois ou plus. Les variations sont signalées, mais deux repères différents sur une même page peuvent semer le doute. Odelina doit faire valider et harmoniser toute donnée de cicatrisation avant publication.
5. Hors sujet santé mais révélateur du contrôle éditorial : <https://nebuleusebijoux.com/pages/faqs> promet un site « sécurisé à 100 % » et des données qui ne peuvent être piratées. Ces garanties absolues ne sont pas une bonne base de réassurance.

## 5. Cinq enseignements originaux pour Odelina

### 1 — Faire des guides une aide à composer

Depuis une zone du Composer, proposer « Comprendre cet emplacement » ; depuis le guide, proposer « Voir les pièces pour ma composition ». Le retour conserve le set, l'oreille et la zone sélectionnés. Le guide devient un outil de décision, pas une destination éditoriale isolée.

### 2 — Enseigner les trois mesures avant d'afficher des valeurs

Un schéma Odelina distingue longueur utile de barre, épaisseur et diamètre intérieur d'anneau ; un second montre la taille du décor. Chaque sélecteur utilise le libellé complet et les unités. Donner une méthode pour relever un bijou déjà adapté, préciser que les tableaux sont indicatifs et orienter vers un perceur en cas d'incertitude. Ne pas importer les tableaux chiffrés du concurrent.

### 3 — Transformer le set en point de départ personnel

Sur chaque set Odelina : montrer les pièces incluses, les emplacements prévus, le nombre de trous requis, la répartition par oreille et les dimensions disponibles. Un bouton **« Adapter ce set dans le Composer »** ouvre le set déjà chargé. La cliente peut remplacer une pièce en comprenant l'effet sur l'équilibre, le prix et la compatibilité de la composition.

### 4 — Rédiger une page d'entretien utilisable en trente secondes

Une routine courte puis un tableau par matière/finition vérifiée ; identifier les précautions liées au placage, aux pierres et aux fermoirs selon les références Odelina. Ajouter des précisions de stockage pour un set complet. Séparer nettement « entretenir un bijou retiré » de « piercing récent : suivre les consignes du professionnel ». La fiche produit et le Composer affichent uniquement le conseil pertinent pour la pièce.

### 5 — Faire de la cohérence une preuve de qualité

Stocker une seule fois les données matière, dimension, fermeture, finition et restrictions produit ; les réutiliser dans les fiches, les sets, les guides et le panier. Afficher une date de révision et un responsable de validation pour les conseils sensibles. Vérifier les liens, les unités et les promesses avant publication. Un ton Odelina sobre et chaleureux peut être rassurant sans multiplier les superlatifs ni les garanties absolues.

## Sources et fichiers de preuve

Tous les constats ci-dessus ont été contrôlés le 18 octobre 2026. Les fichiers `.html` conservent le HTML reçu ; les fichiers `.txt` en sont des extractions de travail. Les fichiers `*-rendered.txt` correspondent au texte rendu dans Chromium. Les captures portent le nom de la page et le format.

| Référence | URL | Preuve principale |
|---|---|---|
| N1 | https://nebuleusebijoux.com/products/andrea-titane | `titanium.txt`, `titanium-desktop.png`, `titanium-mobile.png` |
| N2 | https://nebuleusebijoux.com/products/anneau-leonie | `ring.txt`, `ring-desktop.png`, `ring-mobile.png` |
| N3 | Même fiche Anneau Léonie, guide ouvert | `size-guide-desktop.png`, `size-guide-mobile.png`, textes associés |
| N4–N5 | https://nebuleusebijoux.com/blogs/blog/meilleurs-piercings-doreille-le-guide-et-notre-selection | `guide.html`, `guide.txt` ; contrôle GET 404 du lien Daith |
| N6 | https://nebuleusebijoux.com/blogs/blog/prendre-soin-de-ses-bijoux | `care.txt`, `care-desktop.png`, `care-mobile.png` |
| N7 | https://nebuleusebijoux.com/pages/soins-apres-un-piercing → https://nebuleusebijoux.com/products/reservation-piercing | `aftercare.html`, `aftercare.txt` ; redirection GET contrôlée |
| N8 | https://nebuleusebijoux.com/pages/expertise | `expertise.html`, `expertise.txt` |
| N9 | https://nebuleusebijoux.com/collections/sets | `sets.txt`, `sets-desktop.png`, `sets-mobile.png` |
| N10 | https://nebuleusebijoux.com/products/composition-lumineuse | `composition.txt`, `composition-desktop.png`, `composition-mobile.png` |
| FAQ | https://nebuleusebijoux.com/pages/faqs | `faq.html`, `faq.txt` |
| Accueil | https://nebuleusebijoux.com/ | `home.html`, `home-desktop.png`, `home-mobile.png` |

### Limites techniques

Le premier essai Chromium direct a rejeté le certificat du proxy de l'environnement. Aucun contournement TLS n'a été utilisé. Les captures ont ensuite été produites dans Chromium en faisant passer les requêtes GET par l'API Playwright configurée avec le proxy existant et sa chaîne de confiance. La vérification TLS est restée active. Les requêtes POST et plusieurs domaines de mesure publicitaire ont été bloqués : les captures documentent la présentation et les interactions locales de lecture, pas le fonctionnement des outils analytiques, d'un compte ou du tunnel de paiement.
