# By Les Audacieuses — audit contenu et parcours pour Odelina

**Date de consultation : 18 octobre 2026.** Analyse de pages publiques, en français. Objectif : améliorer l’aide au choix, les sets et le Composer d’Odelina, sans ouvrir de forum ni construire un blog d’articles.

## Lecture principale

By Les Audacieuses associe un catalogue très segmenté par emplacement à une voix de marque incarnée par deux perceuses. Sa force la plus directement transposable à Odelina est la présence d’informations techniques précises et d’un tableau des tailles accessible au moment du choix du bijou. Sa faiblesse est la dispersion de l’aide : tableau contextuel, ancien guide en image, nouveau PDF à recevoir par email, articles longs et FAQ présentent des niveaux de précision différents.

L’opportunité d’Odelina n’est pas de reproduire ce volume éditorial. Elle est de transformer une même information fiable en trois usages continus : comprendre son oreille, choisir les bonnes dimensions, puis retrouver ces choix dans son set ou dans le Composer.

## Périmètre et limites

- Lecture réelle des HTML et textes rendus : accueil, fiche Oser, collection hélix, offre combo, trois variantes de guide des tailles, page emplacements, entretien et changement, nettoyage, article dimensions d’anneaux, article matériaux, article hygiène, FAQ, page réglage threadless, quiz composition et page Mix and Match.
- Recherche dans le menu et le sitemap public avant toute conclusion sur les fonctionnalités. Cela a permis de trouver des pages de composition peu visibles dans le menu rendu.
- Rendu Chromium à 1 440 × 1 000 et 390 × 844 pour accueil, fiche Oser, nouveau guide et entretien. Autres captures desktop : ancien guide, emplacements, quiz, Mix and Match, tableau de tailles ouvert depuis la fiche.
- Pour conserver la vérification TLS dans cet environnement, les requêtes GET du navigateur ont été transmises par urllib utilisant le magasin de certificats système. Aucun `ignoreHTTPSErrors`, aucune désactivation de vérification. Les soumissions de formulaires ont été bloquées ; aucune inscription, aucun achat et aucun message n’ont été envoyés.
- Le formulaire du guide a bien chargé ; le PDF n’a pas été demandé. La vidéo YouTube n’a pas chargé dans cet environnement. Les modules quiz et Mix and Match n’ont pas été entièrement rendus ; leur qualité fonctionnelle n’est donc pas évaluée. Ce constat ne prouve pas qu’ils ne fonctionnent pas pour les visiteurs.
- Panier et paiement non testés : audit de l’aide jusqu’au bouton d’ajout, pas de certification d’un parcours transactionnel complet. Les réductions et conditions sont rapportées telles qu’affichées, sans contrôle de leur application effective.
- Les captures ne constituent pas un test de performance, de conformité générale ou d’accessibilité complète.

## Preuves vérifiées et implications distinctes

### A1 — Une architecture par besoin anatomique

**Preuve.** Le menu de l’accueil propose une entrée « Emplacement » avec hélix, conch, tragus, anti-hélix, rook, daith, lobe et d’autres zones ; le catalogue est également accessible par forme de bijou. L’accueil présente une section « Explorer par emplacement ».

**URL :** https://bylesaudacieuses.com/ — consultée le 18/10/2026.

**Interprétation.** La personne qui connaît déjà le nom de son piercing dispose d’un raccourci efficace. Une personne qui ne connaît pas ce vocabulaire a encore besoin d’une carte visuelle et d’un équivalent en langage courant. Pour Odelina, la sélection d’une zone doit aussi ouvrir les sets qui utilisent cette zone et positionner le Composer sur celle-ci.

### A2 — Une fiche techniquement plus claire que les articles généraux

**Preuve.** La fiche Oser présente un anneau double à 34 € au moment de la visite, deux coloris et quatre diamètres affichés : 6, 8, 10 et 12 mm. La fiche précise le matériau annoncé (titane ASTM F136), l’épaisseur de tige de 1,2 mm, la fermeture à charnière/clip, les emplacements annoncés compatibles et la vente à l’unité. Photos du bijou seul et porté disponibles. Les options indisponibles sont barrées. Une aide à la taille et l’entretien sont proposés.

**URL :** https://bylesaudacieuses.com/products/piercing-anneau-oser-titane — consultée le 18/10/2026.

**Interprétation.** Les détails structurés rendent le produit compréhensible et comparable. En revanche, le sélecteur principal est libellé simplement « Taille » : la différence entre diamètre, longueur et épaisseur repose sur les informations plus bas. Les emplacements sont listés globalement, sans qu’un diamètre soit expliqué pour une morphologie particulière. Odelina peut faire mieux avec « Diamètre intérieur de l’anneau », un schéma de mesure et une réponse qui reste prudente sur l’anatomie.

**Nuance.** La certification et les allégations matériaux sont celles du vendeur ; les justificatifs produits n’ont pas été audités.

### A3 — Un tableau des tailles dans le contexte du choix

**Preuve.** Sur la fiche Oser rendue, un lien « Tableau des tailles » se trouve avant le bouton d’ajout au panier. Son ouverture affiche une fenêtre intitulée « Tableau des tailles : piercing oreille ». Le document est une image et porte explicitement sur les piercings cicatrisés. Il comporte des colonnes « Emplacements », « Anneau (diamètre interne) », « Labret (longueur de tige) » et « Attention ».

**URL :** https://bylesaudacieuses.com/products/piercing-anneau-oser-titane — interaction observée le 18/10/2026.

**Interprétation.** C’est un bon emplacement de l’aide : l’utilisateur reste sur le produit. Mais un grand tableau en image fait porter tout l’effort de lecture sur le zoom et ne fournit pas de texte équivalent détaillé dans le corps rendu. Un tableau HTML filtré sur la zone choisie serait plus simple sur mobile et réutilisable dans le Composer.

**Prudence éditoriale.** La colonne « Attention » contient aussi des recommandations d’ajustement ou d’accessoires, par exemple le silicone pour modifier le positionnement d’un bijou. Ne pas transformer ce type de conseil en règle produit universelle chez Odelina : il doit être évalué par un professionnel compétent pour le cas réel.

### A4 — Un nouveau guide conditionné à la saisie d’un email

**Preuve.** La page « Guide des tailles – PDF gratuit » affiche un champ email et un bouton de réception du guide, avec une promesse de PDF imprimable. Un lecteur vidéo est intégré plus bas. Aucun tableau de mesure HTML immédiatement consultable n’a été observé sur cette page.

**URL :** https://bylesaudacieuses.com/pages/guide-des-tailles-telecharge-ton-pdf-gratuit — consultée et visualisée le 18/10/2026.

**Interprétation.** C’est une bonne idée de proposer un support imprimable. L’email devient cependant une étape supplémentaire avant la décision d’achat. Pour Odelina : aide essentielle ouverte directement, version PDF téléchargeable en complément ; aucune collecte de données nécessaire pour comprendre sa taille. La promesse d’un choix « à coup sûr » observée dans ce formulaire est trop absolue pour une mesure dépendant de l’anatomie et de la méthode d’impression.

### A5 — Plusieurs guides coexistent avec des contenus différents

**Preuve.** L’ancien guide affiche une seule image de tableau. Elle présente emplacements, formes, épaisseurs et longueurs/diamètres. Une autre URL « guide-des-tailles-1 » existe et son extraction inclut une balise Klaviyo affichée comme texte, ce qui indique au minimum un contenu résiduel à contrôler. Ces pages ont été retrouvées dans le sitemap public.

**URLs :**

- https://bylesaudacieuses.com/pages/guide-des-tailles
- https://bylesaudacieuses.com/pages/guide-des-tailles-1
- https://bylesaudacieuses.com/sitemap.xml

Consultées le 18/10/2026.

**Interprétation.** La multiplication des portes d’entrée crée un risque de versions concurrentes et de maintenance inégale. Odelina devrait stocker les données techniques dans une source unique et générer la page, l’aide contextuelle et l’export à partir de cette source. Les tailles concurrentes ne doivent pas être importées comme vérité propre à Odelina.

### A6 — La taille est expliquée, mais la réponse utile se dilue

**Preuve.** L’article sur les anneaux distingue l’épaisseur du bijou de son diamètre, donne des exemples par emplacement et avertit que les standards varient selon la morphologie et l’emplacement du trou. Il renvoie au perceur. Il contient aussi plusieurs métaphores et des apartés humoristiques ; le texte passe par de longues introductions avant d’arriver aux mesures.

**URL :** https://bylesaudacieuses.com/blogs/blog-by-les-audacieuses/quelle-taille-danneau-est-adaptee-a-mon-piercing — consultée le 18/10/2026.

**Interprétation.** L’intention pédagogique est réelle. Pour un achat mobile, le meilleur ordre serait : 1. ce que je mesure, 2. le schéma, 3. la méthode, 4. la limite, 5. les bijoux compatibles. Odelina peut garder une voix chaleureuse avec une phrase courte par action et réserver les explications complémentaires à un niveau secondaire.

### A7 — L’entretien est une porte vers plusieurs articles

**Preuve.** La page « Entretien & Changement de vos bijoux » introduit une série de sujets et les relie via des vignettes en image : hygiène de changement, matériaux, taille d’anneau, intolérance à l’anneau et nettoyage. Le lien sur les matériaux apparaît deux fois. Plusieurs images-liens ont un attribut `alt` vide dans le HTML. Dans le rendu desktop consulté, les vignettes forment une colonne étroite à gauche avec un grand espace disponible à droite.

**URL :** https://bylesaudacieuses.com/pages/entretien-changement-de-vos-bijoux — consultée et visualisée le 18/10/2026.

**Interprétation.** Le visiteur doit choisir un autre contenu avant d’obtenir la routine. Pour Odelina, une page permanente « Entretenir mes bijoux » doit donner la réponse directement, puis relier les exceptions. Les intitulés doivent être de vrais textes et les liens compréhensibles sans dépendre d’un visuel.

### A8 — Un tutoriel de nettoyage concret, à bien délimiter

**Preuve.** L’article de nettoyage commence par préciser qu’il traite les bijoux portés dans des piercings entièrement cicatrisés. Il fournit une liste de matériel, puis une séquence de lavage, brossage, rinçage et séchage. Il propose une routine mensuelle. La fiche Oser contient de son côté un résumé d’entretien avec savon doux, séchage et précautions face aux produits capillaires.

**URLs :**

- https://bylesaudacieuses.com/blogs/blog-by-les-audacieuses/comment-nettoyer-correctement-ses-piercings
- https://bylesaudacieuses.com/products/piercing-anneau-oser-titane

Consultées le 18/10/2026.

**Interprétation.** La liste de matériel et la succession d’étapes sont utiles. La variation entre « savon antibactérien » dans l’article et « savon doux » dans la fiche illustre un besoin d’harmonisation. Odelina doit définir sa routine d’après les matériaux, finitions et pierres de ses propres bijoux, en séparant l’objet de l’entretien de la peau et de la cicatrisation. Ne pas copier une fréquence mensuelle ou un produit de nettoyage sans vérifier l’adéquation au catalogue.

### A9 — Des explications matériaux riches, parfois trop affirmatives

**Preuve.** Un article compare acier inoxydable, acier 316L, titane ASTM F136, or et argent avec avantages et limites. Il attire notamment l’attention sur le fait qu’une tige et son embout peuvent être de matériaux différents. Des formulations présentent cependant une sécurité ou une tranquillité « totale » ; l’or 18 carats est qualifié de « pur », formulation techniquement imprécise.

**URL :** https://bylesaudacieuses.com/blogs/blog-by-les-audacieuses/aciers-de-bijoux-de-piercing-decryptage-des-avantages-et-inconvenients-pour-une-selection-eclairee — consultée le 18/10/2026.

**Interprétation.** La distinction tige/ornement est excellente pour Odelina : préciser chaque composant, la finition et les preuves disponibles. L’argument de confiance doit venir d’une information exacte et traçable, et ne pas promettre l’absence de réaction ou une cicatrisation idéale.

### A10 — Des conseils de changement qui demandent une gouvernance éditoriale

**Preuve.** Le guide d’hygiène liste des formes de bijoux selon la zone, distingue le bijou cicatrisé et conseille de consulter face à une difficulté ou à certains symptômes. La FAQ contient plusieurs réponses sur les délais : cicatrisation décrite en mois, passage à l’anneau sur cartilage après un autre délai, et changement de bijou évoqué à trois mois pour le cartilage. Le downsizing professionnel n’est pas clairement séparé du changement esthétique autonome dans ces réponses.

**URLs :**

- https://bylesaudacieuses.com/blogs/blog-by-les-audacieuses/guide-de-securite-et-dhygiene-pour-lachat-et-le-changement-dun-piercing-cicatrise
- https://bylesaudacieuses.com/pages/faq

Consultées le 18/10/2026.

**Interprétation.** Ce sont des formulations potentiellement ambiguës pour un débutant, plutôt qu’une preuve de contradiction médicale dans tous les cas. Odelina doit expliquer le sens des étapes et éviter de faire d’un délai fixe une autorisation de changer seul son bijou. La validation de la cicatrisation ou d’une complication relève d’un professionnel compétent.

### A11 — Un exemple à exclure des textes Odelina

**Preuve.** Un article présente l’huile essentielle de tea tree comme très efficace contre les « chéloïdes » de piercing et donne une recette d’application répétée. Il assimile cette appellation à différentes petites boules d’irritation. Un lien commercial vers l’huile apparaît en fin d’article.

**URL :** https://bylesaudacieuses.com/blogs/blog-by-les-audacieuses/quest-ce-que-lhuile-essentielle-de-tea-tree-un-petit-genie-australien-anti-cheloide-dans-une-bouteille — consultée le 18/10/2026.

**Interprétation.** La présence d’un texte chez un concurrent n’en établit pas la validité médicale. Odelina ne doit reprendre ni la recette, ni la confusion de diagnostic, ni une promesse thérapeutique. La page entretien doit rester centrée sur le bijou ; une question de peau doit mener à un avis professionnel adapté.

### A12 — Une offre commerciale de plusieurs bijoux, distincte d’un set composé

**Preuve.** L’accueil et la fiche Oser annoncent une remise de 10 % dès deux bijoux et de 15 % dès trois, avec des exclusions. La collection « Offre combo » affiche 103 résultats au moment de la visite. Le contenu observé est une liste de produits individuels.

**URLs :**

- https://bylesaudacieuses.com/
- https://bylesaudacieuses.com/collections/offre-combo
- https://bylesaudacieuses.com/products/piercing-anneau-oser-titane

Consultées le 18/10/2026.

**Interprétation.** La mécanique de quantité est immédiatement lisible. Un set Odelina doit offrir une valeur supplémentaire identifiable : harmonie expliquée, liste des emplacements, adaptation aux trous déjà présents, dimensions par pièce et possibilité de modifier une pièce dans le Composer. Une simple réduction n’explique pas la qualité d’une composition.

### A13 — Une proposition de composition personnalisée existe

**Preuve.** La page « Quizz compo personnalisée » présente une sélection personnalisée proposée par Julie, cofondatrice et perceuse, adaptée au style et à l’oreille. Elle annonce un service gratuit sans obligation d’achat. Le HTML contient un module Octane AI. Une page « Mix and Match » contient un module de bundle. Ni l’un ni l’autre n’a produit un parcours complet dans la session d’audit. Une ancienne URL « creer-ma-composition » trouvée dans une configuration de menu renvoie 404 ; cela n’annule pas l’existence des pages actuelles.

**URLs :**

- https://bylesaudacieuses.com/pages/compose-ton-oreille-ideale
- https://bylesaudacieuses.com/pages/collection-bundle
- https://bylesaudacieuses.com/pages/creer-ma-composition

Consultées le 18/10/2026.

**Interprétation.** Il serait inexact d’écrire que ce concurrent ne propose aucune personnalisation. La comparaison possible porte ici sur la promesse éditoriale, pas sur la richesse effective des outils. Odelina doit rendre tangible et immédiatement essayable son Composer, expliquer la différence entre « partir d’un set » et « créer ma composition », et montrer ce qui reste personnalisable.

### A14 — Un guide emplacements existe comme URL, mais son contenu n’est pas vérifié

**Preuve.** La page « Emplacements des piercings » existe et répond en HTTP 200 ; le corps éditorial du HTML est vide. Dans le rendu obtenu, seul le titre et l’aide générale de la boutique apparaissent. Les collections par zone, comme hélix, apportent en revanche du texte descriptif.

**URLs :**

- https://bylesaudacieuses.com/pages/emplacements-des-piercings
- https://bylesaudacieuses.com/collections/piercing-helix

Consultées le 18/10/2026.

**Interprétation.** Il est impossible d’en tirer un exemple complet de guide visuel. Odelina dispose d’une opportunité concrète : carte anatomique accessible, liste textuelle correspondante, photos portées et connexion directe au Composer. Il ne faut pas présenter comme absence certaine ce que l’audit n’a pas pu rendre.

### A15 — Des preuves de confiance à harmoniser jusque dans les visuels

**Preuve.** Sur l’accueil entièrement chargé, un bloc promotionnel affiche 5 ans d’expertise et plus de 3 000 clientes ; un bloc plus bas annonce plus de 6 ans et plus de 40 000 clientes. Le périmètre distinct de ces chiffres n’est pas expliqué dans les blocs observés.

**URL :** https://bylesaudacieuses.com/ — visualisée le 18/10/2026. Capture `home-desktop-loaded.png`.

**Interprétation.** Cela ne permet pas de conclure que ces chiffres sont faux ; cela montre que les éléments de réassurance ne sont pas harmonisés ou contextualisés. Odelina doit traiter le texte intégré aux images comme du contenu à maintenir, avec les mêmes sources et dates que les textes HTML.

## Cinq enseignements transposables sans copie

1. **Faire vivre les guides dans le choix.** Garder trois pages permanentes, puis ouvrir l’extrait pertinent depuis la fiche, le set et le Composer. Afficher l’aide à côté de l’option qui fait hésiter ; conserver la sélection à la fermeture.
2. **Distinguer trois dimensions dans un langage stable.** Diamètre intérieur d’un anneau, longueur utile d’une tige, épaisseur de tige. Un schéma propre à Odelina, une légende textuelle, une méthode et une limite explicite valent mieux qu’un tableau de chiffres isolés. Aucune taille universelle par zone.
3. **Rendre la composition explicable.** Sur chaque set, relier chaque bijou à son emplacement et à son rôle visuel : point de lumière, volume, équilibre, mouvement. Proposer « Adapter ce set dans le Composer ». Ces explications constituent une expertise de composition propre à Odelina.
4. **Écrire court d’abord, détaillé ensuite.** Réponse en une phrase, étape illustrée, détail en accordéon, puis prochaine action. Garder une voix chaleureuse cohérente et éviter les promesses absolues. Relire les textes pour harmoniser vocabulaire, dimensions et entretien entre toutes les surfaces.
5. **Séparer clairement entretenir et soigner.** Fiches matériaux et entretien basées sur le catalogue réel ; aucun diagnostic, remède ou calendrier de cicatrisation transformé en garantie commerciale. Identifier auteur, date de mise à jour et relecteur compétent pour les sujets qui touchent à la peau.

## Application priorisée pour Odelina

| Priorité | Proposition | Valeur pour le set / Composer | Preuves de veille |
|---|---|---|---|
| P0 | Aide dimensionnelle contextualisée, sans email obligatoire | Choisir une dimension sans perdre sa composition | A2–A6 |
| P0 | Chaque pièce d’un set possède un emplacement, une dimension et un statut à vérifier | Comprendre ce que le set contient et ce qui doit être adapté | A2, A12 |
| P0 | Une source commune de données pour fiches, guide, Composer et panier | Réduire les versions incohérentes | A5, A8–A10 |
| P1 | Carte emplacements avec équivalent textuel et CTA « Voir dans le Composer » | Passer de l’anatomie à une composition utile | A1, A14 |
| P1 | Page entretien ouverte, en étapes, distinguant matière et finition | Prolonger la vie du set et répondre après achat | A7–A9 |
| P1 | Explications d’harmonie sur les sets + modification pièce par pièce | Rendre visible la valeur ajoutée Odelina | A12, A13 |

## Captures disponibles

Toutes dans `/workspace/research-odelina/audacieuses/` :

- `product-desktop.png`, `product-mobile.png` : fiche et hiérarchie des choix.
- `product_help-desktop.png`, `product_help-mobile.png` : tableau des tailles ouvert ; le mobile confirme une image affichée très petite à 390 px de largeur.
- `guide_tailles-desktop.png`, `guide_tailles-mobile.png` : guide PDF et formulaire effectivement rendu.
- `entretien-desktop.png`, `entretien-mobile.png` : page d’orientation vers les articles.
- `home-desktop.png`, `home-mobile.png` : première série avec images en chargement différé ; préférer `home-desktop-loaded.png` pour une vue complète, chargement différé vérifié par défilement.
- `tailles_html-desktop.png` et `guide-image-original.png` : ancien guide en image.
- `emplacements-desktop.png`, `oreille-desktop.png`, `bundle-desktop.png` : état obtenu, utile pour documenter les limites de l’observation ; ne pas utiliser pour conclure à un défaut systématique.

Les fichiers `.html` et `.txt` associés permettent de retrouver les preuves textuelles. Ces captures servent à documenter la veille ; elles ne sont pas des maquettes à copier.
