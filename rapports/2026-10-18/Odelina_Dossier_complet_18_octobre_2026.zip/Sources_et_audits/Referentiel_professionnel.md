# Référentiel éditorial : tailles, emplacements et entretien Odelina

Consultation réelle des sources : **18 octobre 2026**. Les réponses HTTP, URL finales, volumes et heures figurent dans les fichiers `fetch-log*.json` de ce dossier ; les instantanés HTML et textes sont conservés à côté. Ce document encadre une rédaction commerciale ; il ne constitue ni un diagnostic ni un protocole de soins individuel.

## 1. Règles qui doivent guider les futurs contenus

### Tailles : expliquer une mesure, ne pas promettre une taille universelle

L'Association of Professional Piercers (APP) indique que longueur, diamètre et épaisseur doivent être adaptés à l'anatomie et à l'emplacement. Un bijou trop serré ou trop grand présente des difficultés différentes ; un nom d'emplacement ne suffit donc pas pour choisir. La page du guide doit aider à **comprendre les dimensions et préparer un choix**, avec recours au perceur si la mesure n'est pas connue. [S1, S3]

Conventions éditoriales proposées pour Odelina, à vérifier sur les mesures réelles du catalogue :

| Terme à afficher | Explication simple | Validation nécessaire |
|---|---|---|
| Épaisseur de la tige — mm | Diamètre de la partie qui traverse le piercing ; ce n'est ni le diamètre de l'anneau ni la taille du motif. | Mesure de chaque référence ; équivalence « G » fournie par le fabricant si elle est affichée. Privilégier les mm. |
| Longueur utile — mm | Sur un labret droit, espace de tige disponible entre les faces intérieures de la base et de l'embout. | Confirmer la convention fournisseur, et utiliser un dessin spécifique pour une barre courbe ; ne pas confondre longueur totale et utile. |
| Diamètre intérieur — mm | Espace mesuré à l'intérieur de l'anneau, sans inclure son épaisseur. | Vérifier que le chiffre catalogue est bien intérieur et non extérieur. Un anneau décoratif peut être non circulaire. |
| Dimensions du motif — mm | Encombrement visible de l'ornement. | Distinguer largeur, hauteur et éventuel pendant, utiles pour composer un set sans collision visuelle. |

Ces définitions sont des conventions de présentation géométrique à faire correspondre aux fiches fournisseur ; **l'APP justifie l'importance des trois dimensions mais ne prescrit pas cette convention de mesure commerciale détaillée**. Ne pas attribuer ces définitions ou un tableau de tailles Odelina à l'APP.

**Formulations conseillées** : « Chaque oreille est différente. La bonne taille dépend de votre anatomie, de la position du trou et du rendu souhaité. » ; « Si vous ne connaissez pas votre taille, faites-la vérifier par votre perceur avant de commander. »

**À éviter** : « Pour un hélix, prenez toujours 6 mm » ; un tableau « emplacement = taille exacte » ; une mesure sur photo présentée comme fiable ; une conversion automatique de gauge qui écrase la mesure fournisseur.

### Emplacements : relier les repères à la composition, sans diagnostic

Une carte d'oreille peut nommer les principaux emplacements et illustrer les silhouettes possibles. Elle doit préciser qu'elle sert de **repère visuel** : tous les emplacements ne sont pas réalisables sur toutes les anatomies et tous les bijoux proposés pour un emplacement n'ont pas la même taille. [S1, S3]

Pour chaque emplacement : nom simple, zone sur la carte, silhouette de bijou proposée, dimensions à vérifier, exemple de set et bouton « L'essayer dans ma composition ». Le détail de la faisabilité, du placement et d'une première pose relève d'un perceur qualifié. Le composer ne doit pas se présenter comme un contrôle médical d'adaptation.

**Formulation conseillée** : « Une idée de bijou pour cet emplacement. La taille et l'adaptation à votre oreille restent à vérifier. »

Un statut « compatible » exige une règle vérifiable : variante et taille renseignées, système de fixation compatible, emplacement prévu. Si seuls le style et le nom d'emplacement sont connus, écrire « suggestion pour cet emplacement » ou « association de style », et conserver l'incertitude.

### Matières : une norme de matière ne certifie pas toute la marque

L'APP cite le titane Ti-6Al-4V ELI conforme à ASTM F136 et le titane commercialement pur conforme à ASTM F67 parmi les matières pertinentes pour les premières poses ; elle souligne aussi l'importance de la finition, du montage, de la taille et des documents matière. Une seule mention « titane » ne démontre donc ni la nuance ni l'aptitude complète d'un bijou fini à une première pose. [S1]

Les fiches publiques ASTM confirment les intitulés et le périmètre matière de F136 et F67 : exigences pour des produits en titane ou alliage destinés à la fabrication d'implants chirurgicaux. **Elles ne constituent aucune preuve que les bijoux Odelina sont conformes.** Le texte intégral des normes n'a pas été acquis ni utilisé pour une évaluation technique. [S5, S6]

Avant de publier « conforme ASTM F136 » : obtenir une documentation matière traçable au produit/lot auprès du fournisseur. Vérifier séparément la finition dorée, la structure du décor et le système d'assemblage. Ne pas transformer l'absence d'alerte ou une simple description fournisseur en certification indépendante.

**Formulation conditionnelle, seulement après justificatifs** : « Tige en titane Ti-6Al-4V ELI, conforme à la norme ASTM F136 selon la documentation de notre fournisseur. » Préciser les autres composants si leur matière diffère.

**À éviter sans preuve adaptée** : « certifié APP », « certifié médical », « zéro allergie », « 100 % hypoallergénique », « sans nickel » comme garantie absolue, ou une promesse identique pour la tige, le plaquage, les soudures et les ornements. L'APP indique notamment que l'or plaqué n'est pas approprié aux premières poses ; cela ne permet pas de classer toute finition dorée sans connaître sa nature exacte. [S1]

## 2. Entretien du bijou : un contenu différent des soins d'un piercing

La page demandée par Odelina peut rester une **page de service permanente**, reliée aux fiches produit, aux sets et au composer, sans créer un blog ni un forum.

Commencer par un choix lisible : « Entretenir un bijou retiré » / « Mon piercing est en cours de cicatrisation ». Ce second choix mène vers un court encadré de prudence et les conseils du perceur, plutôt que vers une recette de nettoyage du métal à appliquer sur la peau.

### Bijou retiré : méthode à confirmer selon toute sa composition

Proposition conservatrice à faire valider par les fournisseurs Odelina :

1. Identifier la matière de la tige **et** la finition, les pierres/perles, l'éventuelle colle et le type de fixation.
2. Manipuler le bijou avec des mains propres et l'essuyer doucement avec un chiffon doux, propre, non abrasif ; ne pas supposer qu'une chamoisine imprégnée convient à un revêtement.
3. Pour un nettoyage à l'eau, au savon ou par immersion : publier uniquement une méthode confirmée pour la référence concernée. Sécher soigneusement si l'eau est autorisée.
4. Ranger les pièces séparément, dans un espace sec, pour limiter les frottements entre les éléments d'un set.
5. Éviter par défaut brossage abrasif, dentifrice, bicarbonate, vinaigre, javel, alcool, ébullition, ultrasons et nettoyant pour argent tant que leur compatibilité n'est pas confirmée. Cette liste est une précaution éditoriale pour une composition inconnue, et non une affirmation que chaque procédé endommage tout titane.

Le guide officiel Pandora illustre pourquoi les protocoles ne se généralisent pas : ses consignes spécifiques aux perles excluent notamment trempage et frottement appuyé, tandis que d'autres produits de la marque suivent une autre méthode. **Son kit et ses temps de trempage ne doivent pas être prescrits pour Odelina.** [S7]

Le titane nu, le titane anodisé, une finition PVD/dorée, un plaquage d'or, une pierre sertie et une pierre collée ne sont pas des catégories interchangeables. L'APP indique par exemple que certaines couleurs anodisées peuvent s'estomper sous l'effet de la chimie corporelle ou des frottements ; cela n'établit aucune garantie de tenue de la finition Odelina. [S1]

Ne pas écrire une routine universelle « retirez tous vos piercings chaque soir/pour vous laver ». L'APP rappelle qu'un canal même ancien peut se resserrer rapidement. Écrire : « Si votre bijou peut être retiré sans difficulté et que votre piercing est cicatrisé, suivez la méthode correspondant à sa matière. En cas de doute, demandez conseil à votre perceur. » Le statut de cicatrisation ne se déduit pas d'un délai unique. [S2, S3]

### Piercing en cicatrisation : encadré court, pas de promesse de guérison

L'APP recommande des mains propres, une solution saline stérile à 0,9 % conçue pour le lavage des plaies et sans additifs inadaptés, et déconseille rotation du bijou, alcool, eau oxygénée et nettoyage excessif. Elle ne recommande plus les mélanges salins maison. Elle indique aussi qu'un aspect extérieur rassurant ne prouve pas que l'intérieur est cicatrisé. [S2]

Les changements de bijou pendant la cicatrisation, notamment un ajustement de longueur (« downsize »), doivent être réalisés par un perceur qualifié ; ne pas suggérer d'enlever le bijou pour suivre une routine d'entretien du métal. Les charms et objets suspendus sont à réserver aux piercings complètement cicatrisés selon l'APP. [S2]

**Formulation publiable après relecture professionnelle** : « Les conseils de cette page concernent l'entretien de vos bijoux. Si votre piercing est récent ou encore en cicatrisation, suivez les recommandations de votre perceur avant toute manipulation ou tout changement. Une douleur qui augmente, une zone chaude ou gonflée, un écoulement inhabituel ou un malaise nécessitent un avis médical rapide. » [S2, S4]

Ne pas fixer un délai universel « cicatrisé en X semaines », une date automatique de passage à un anneau, ni une intensité de douleur standard. Le perceur peut guider l'adaptation du bijou ; les signes d'infection relèvent d'un professionnel de santé. Le NHS indique de ne pas retirer soi-même le bijou en cas d'infection suspectée sauf consigne médicale. [S4]

## 3. Désaccords et limites à conserver dans la synthèse

- **APP / NHS** : la page NHS consultée conseille encore une rotation douce pendant le nettoyage et de l'eau salée ; la page APP consultée déconseille la rotation et les mélanges salins maison. Ne pas assembler ces conseils en un faux consensus. Pour cette veille, utiliser l'APP pour les principes de soin et le NHS pour les signes d'alerte et le recours médical.
- **Dates** : les brochures APP affichent une publication au 3 mai 2020 ; cette date ne prouve pas la dernière mise à jour du texte. Le NHS affiche « dernière révision : 18 avril 2023 » et une révision attendue au 18 avril 2026, donc dépassée à la date de consultation. Les recommandations destinées à publication doivent être relues par un professionnel du piercing, et les alertes médicales si nécessaire par un professionnel de santé.
- **Pas de validation Odelina** : cette recherche n'a pas examiné les certificats matière, mesures réelles, essais de revêtement, pierres, colles, stocks ou conditions de garantie d'Odelina. Les conseils d'entretien par référence restent à confirmer.
- **AAD** : deux anciennes URL supposées ont renvoyé 404 ; une troisième a redirigé vers l'index des actualités, sans article ciblé. Aucune n'est utilisée comme preuve. Voir les fichiers de log pour les tentatives. Ne pas citer une page AAD non consultée.
- **Autre page APP** : `https://safepiercing.org/troubleshooting/` a été consultée mais n'est pas retenue pour écrire une routine : elle comporte des conseils destinés au dépannage et des formulations qui ne doivent pas devenir des recettes commerciales ou médicales. La page principale Aftercare suffit au périmètre demandé.

## 4. Sources consultées et usages précis

| ID | Organisme, page et URL exacte | Constat de consultation / date affichée | Usage et limite |
|---|---|---|---|
| S1 | APP — Jewelry for Initial Piercings : https://safepiercing.org/jewelry-for-initial-piercings/ | HTTP 200 le 18/10/2026. Date éditoriale visible : 03/05/2020. | Adaptation anatomique, trois dimensions, matières F136/F67, documents matière, état de surface et finitions. Guide professionnel ; aucune certification Odelina. |
| S2 | APP — Suggested Aftercare for Body Piercings : https://safepiercing.org/aftercare/ | HTTP 200 le 18/10/2026. Date éditoriale visible : 03/05/2020. | Principes de soin, absence de rotation, pas de sel maison, manipulation et changement professionnel pendant cicatrisation. Pas de délai individuel. |
| S3 | APP — Jewelry for Healed Piercings : https://safepiercing.org/jewelry-for-healed-piercings/ | HTTP 200 le 18/10/2026. Date éditoriale visible : 03/05/2020. | Taille adaptée par perceur, ne pas forcer, retrait/rétrécissement du canal. Ce texte ne définit pas une méthode d'entretien par référence Odelina. |
| S4 | NHS — Infected piercings : https://www.nhs.uk/conditions/infected-piercings/ | HTTP 200 le 18/10/2026. Dernière révision affichée : 18/04/2023 ; révision prévue : 18/04/2026. | Alertes d'infection et consultation médicale rapide. Système de santé britannique ; adapter le recours au public français sans reprendre NHS 111. Conseils courants partiellement divergents de l'APP. |
| S5 | ASTM — F136-26, fiche publique : https://store.astm.org/f0136-26.html | HTTP 200 le 18/10/2026. Version affichée active, mise à jour du 09/02/2026. L'ancienne fiche F136-13(2021)e1 a aussi été consultée, puis distinguée comme historique. | Intitulé et nature de la norme matériau uniquement ; aucun texte intégral acheté ou évaluation de conformité réalisée. |
| S6 | ASTM — F67, fiche publique : https://store.astm.org/f0067-24.html | HTTP 200 le 18/10/2026. | Intitulé et nature de la norme matériau uniquement ; ne certifie pas un produit fini. |
| S7 | Pandora UK — How to clean jewellery : https://uk.pandora.net/en/blog/how-to-clean-jewellery/ | HTTP 200 le 18/10/2026 après redirection de l'ancienne URL « care-and-maintenance ». Pas de date de révision repérée. | Exemple fournisseur de consignes différentes selon les composants, en particulier les perles. Les méthodes et produits sont spécifiques à Pandora et ne sont pas transposés à Odelina. |

## 5. Points à faire valider avant publication

**Par le fournisseur** : composition de chaque composant ; nuance exacte et traçabilité du titane ; nature du doré ; fixation des pierres/perles ; dimensions et méthode de mesure ; compatibilité avec eau, savon et nettoyage ; résistance de la finition ; conditions d'utilisation et garanties.

**Par un perceur qualifié** : carte et noms d'emplacements ; adéquation des familles de bijoux ; place des tailles indicatives ; choix pour piercings cicatrisés ou première pose ; microtextes du composer ; formulation de l'encadré « piercing récent » ; portée du mot « compatible ».

**Par un professionnel de santé si publié** : formulation et orientation des signes d'alerte. Aucun questionnaire du composer ne doit poser un diagnostic ni rassurer automatiquement une personne qui décrit une douleur ou un gonflement.

## 6. Opportunité propre à Odelina

Associer ces pages de service au **set et au composer** : conserver dans chaque composition la position choisie, la variante et les dimensions, proposer une fiche récapitulative compréhensible, puis les consignes d'entretien par bijou avec une attention au composant le plus délicat. Une routine commune n'est proposée que si elle est confirmée pour toutes les pièces du set. Une suggestion esthétique doit rester distincte d'une taille confirmée. Cette approche produit une aide à la décision propre à Odelina, sans copier une page de concurrent ni créer une rubrique d'articles.
