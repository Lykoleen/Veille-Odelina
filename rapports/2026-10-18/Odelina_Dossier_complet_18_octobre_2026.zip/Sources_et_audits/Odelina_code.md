# Odelina — audit du code pour la veille contenu et UX

Observation du 18 octobre 2026. Dépôt lu : `https://github.com/Lykoleen/Odelina`, branche `main`, commit `6897d0f74c0d51383a7e15ad6e92d91a4c91503f` (« Update from Shopify for theme Odelina/main »). Clone de recherche : `/tmp/odelina-source`. Aucun fichier du dépôt modifié, aucune API Shopify appelée, aucune installation ni compilation nécessaire pour cet audit. État Git propre au contrôle final.

**Portée de la preuve :** les constats ci-dessous sont confirmés dans le code et la configuration versionnée de ce commit. Ils ne prouvent pas que ce thème est celui publié à cet instant, ni que les pages Shopify utilisent les templates correspondants. Les menus et certaines données produits vivent dans Shopify et ne sont pas exhaustivement versionnés. Les mentions « à tester » sont des hypothèses de friction, pas des résultats de test utilisateur.

## Ce qu'Odelina possède déjà et qu'il faut préserver

- Un thème Shopify personnalisé et un Composer Preact dédié à `/pages/mes-creations`, chargé sur cette page seulement : `sections/composer.liquid:64`, `:85`, `:121` ; `composer/README.md:1`.
- Onze points de composition : lobe 1/2/3, hélix, hélix avant, flat, rook, daith, conch, tragus, anti-tragus. Le référentiel d'emplacements existe déjà : `composer/src/data/emplacements.js:16`, `composer/src/data/anchors.js:56`.
- Une compatibilité alimentée **par variante** depuis le catalogue d'Aurélie, et non une taille déduite de l'anatomie : `snippets/composer-catalogue.liquid:99`, `composer/src/lib/compat.js:72`, `:94`, `:128`.
- Un guide des tailles partagé entre la page, les fiches produits et le Composer. Source éditoriale unique : `snippets/guide-tailles.liquid:1`, rendu dans `sections/product.liquid:740` et `sections/composer.liquid:115`. C'est une bonne base pour éviter trois versions contradictoires du conseil.
- Des schémas SVG existants pour jauge, longueur utile et diamètre intérieur, des titres hiérarchisés et des en-têtes de tableau avec `scope` : `snippets/guide-tailles.liquid:56`, `:148`.
- Des compositions éditoriales (« Mises en scène ») avec photos portées, pièces identifiées, total calculé depuis les prix réels et finition correspondant à la photo : `sections/stacks.liquid:21`, `:51`, `:130`.
- Un aller-retour set → fiche produit → set à son ancre, prévu dans le code : `sections/stacks.liquid:79`, `:136` et `sections/product.liquid:561`.
- Des embouts explicitement vendus seuls et une barre proposée en complément sur la fiche, selon sa finition et sa disponibilité : `sections/product.liquid:438`, `locales/fr.default.json:210`.
- Un récapitulatif du Composer permettant modifier, retirer, ajouter seul, tout ajouter, enregistrer dans le compte et partager par lien : `composer/src/components/Recap.jsx:143`, `:170`, `:186`, `:197`.
- Des bases d'accessibilité existantes : boutons natifs nommés, états `aria-pressed`, dialogues natifs pour la taille et le guide, cibles de marqueurs de 44 px, styles de focus et réduction des animations : `composer/src/components/ChoixTaille.jsx:51`, `composer/src/components/Oreille.jsx:128`, `composer/src/styles.css:753`, `:763`.

## Les corrections de contenu à traiter en priorité

### 1. Ne pas faire déduire une jauge à partir d'une probabilité

**Confirmé :** le guide affirme que 1,2 mm est la jauge de la grande majorité des perçages, et que si le perçage a été posé en boutique en France, « il y a de fortes chances que ce soit la vôtre » (`snippets/guide-tailles.liquid:50`). La FAQ répète une majorité supposée (`templates/page.faq.json:43`).

**Problème :** une caractéristique du catalogue est transformée en indice sur le corps de la cliente. La jauge du bijou existant doit être connue ; le pays ou le type de boutique ne la détermine pas.

**Texte recommandé :** « Les bijoux Odelina sont proposés en jauge 1,2 mm. Vérifiez que cette épaisseur correspond à votre perçage : consultez votre fiche de pose ou demandez à votre perceur. »

### 2. Retirer le test de la carte bancaire

**Confirmé :** « Une carte bancaire fait 0,76 mm d'épaisseur… si la différence saute aux yeux, vous êtes bien en 1,2 » (`snippets/guide-tailles.liquid:134`).

**Problème :** constater une différence visuelle avec 0,76 ne prouve pas 1,2 ; cela ne départage pas correctement 1,0 / 1,2 / 1,6. Le conseil donne une fausse certitude.

**Remplacement :** fiche de pose/emballage de la pièce existante, mesure adaptée avec un instrument précis sur un bijou déjà retiré et sur un perçage cicatrisé, ou vérification par le perceur. Une règle au millimètre peut aider pour une longueur ou un diamètre ; elle ne suffit pas à valider une jauge avec précision.

### 3. Ne pas proposer une longueur parce que le perçage est gonflé

**Confirmé :** « Prenez 8 mm si votre tissu est épais, ou si votre perçage est encore un peu gonflé » (`snippets/guide-tailles.liquid:172`).

**Problème :** un guide d'achat encourage ici un ajustement en réponse à un gonflement alors que la marque exclut les protocoles de soin et renvoie au perceur. L'emplacement ne suffit déjà pas à choisir une longueur.

**Texte recommandé :** « La longueur dépend de votre anatomie et de votre perçage. Si votre bijou serre, s'enfonce, ou si la zone est gonflée, faites vérifier son ajustement par votre perceur avant de changer de taille. »

### 4. Mettre le guide à jour avec le fonctionnement réel du Composer

**Confirmé :** le tableau annonce des tailles proposées par défaut par emplacement et modifiables « en un clic » (`snippets/guide-tailles.liquid:140`). Le CTA promet une taille « déjà pré-remplie à chaque étape » (`:233`). Le hint dit « La taille se règle après la pose » (`composer/src/components/Conseils.jsx:14`).

**Code réel :** au clic sur Poser, la taille est demandée dans une modale si plusieurs tailles sont proposées ; sinon la pose est immédiate (`composer/src/components/ChoixTaille.jsx:1`, `composer/src/lib/compat.js:165`). La première taille en stock est initialisée (`ChoixTaille.jsx:33`), ce qui est un choix d'interface, pas une recommandation anatomique. Le projet a explicitement écarté les tailles conseillées par emplacement le 2 octobre (`Contexte-projet.md:376`).

**Action :** revoir ensemble guide, tableau, CTA, hint et introduction du Composer. Préférer « Choisissez votre bijou, puis sa taille lorsqu'il existe plusieurs options. Le rendu vous aide à associer les pièces ; il ne vérifie pas l'ajustement à votre oreille. » Le tableau peut présenter les mesures à vérifier et les familles de bijoux, ou des tailles disponibles dans la gamme ; il ne doit pas faire de 6/8 mm une règle de choix pour toutes.

### 5. Harmoniser le vocabulaire de la finition couleur dorée

**Confirmé :** la fiche produit rend une phrase traduite « (PVD Gold sur base titane), pour un confort optimal, nous vous recommandons de patienter jusqu'à la cicatrisation complète… » (`locales/fr.default.json:207`, utilisé par `sections/product.liquid:605`). Le guide utilise « À porter sur un perçage entièrement cicatrisé » (`snippets/guide-tailles.liquid:218`). Le Composer porte seulement « La couleur dorée convient à un piercing cicatrisé » dans sa mention (`templates/page.mes-creations.json:18`).

**Problème :** la recommandation souple de la fiche ne correspond pas au canon interne « piercings entièrement cicatrisés uniquement » (`Contexte-projet.md:255`). « PVD Gold » ne respecte pas non plus la terminologie française choisie par la marque.

**Texte recommandé :** « Titane, finition PVD couleur dorée. Piercings entièrement cicatrisés uniquement. » Préserver les emplacements UI décidés et vérifier la visibilité mobile ; aucun besoin de proposer un pop-up supplémentaire à chaque clic sans test.

### 6. Distinguer matière et bijou prêt à être posé

**Confirmé :** le guide écrit que le titane naturel convient à tous les perçages, « y compris récents ou en cours de cicatrisation » (`snippets/guide-tailles.liquid:210`). L'accueil précise « même sur les piercings récents » (`templates/index.json:184`). La FAQ explique que les bijoux sont non stériles et qu'un perceur doit les poser/stériliser pour un perçage non cicatrisé (`templates/page.faq.json:29`).

**Action :** ne pas laisser le conseil matière se lire comme une consigne de changement autonome d'un perçage récent. Rappeler le professionnel et la livraison non stérile lorsque le contenu aborde cette situation. L'entretien éditorial demandé doit rester centré sur le bijou et les perçages cicatrisés.

### 7. Corriger la phrase de retour du guide

**Confirmé :** « les bijoux de piercing ne pouvant être repris pour des raisons d'hygiène » (`snippets/guide-tailles.liquid:255`). La FAQ autorise au contraire un retour sous 14 jours avec sachet scellé intact et rappelle la garantie de conformité même sachet ouvert (`templates/page.faq.json:117`, `:124`).

**Action :** reprendre la condition exacte du sachet intact et renvoyer à la politique de retour ; ne pas annoncer une impossibilité générale. Faire valider la formulation commerciale/juridique finale.

### 8. Rendre les textes des sets aussi concrets que les fiches produits

**Confirmé :** « En fleurs » décrit les placements et l'effet visuel en une phrase (`templates/page.mise-en-scene.json:206`). « Cascade » multiplie les abstractions (« danse douce », « chaque pièce respire la fluidité », `:151`). « Souveraine » promet « pierres fines », « luxe et prestige », « sanctuaire du beau intemporel » (`:188`).

**Action :** uniformiser à 40–70 mots utiles : emplacement de la pièce principale, principe d'équilibre, détail qui relie les bijoux, déclinaison pour moins de trous. Vérifier la qualification des pierres avant tout emploi de « pierres fines » ; leur nature ne doit pas être déduite du nom du set ni de la photo.

**Exemple de direction éditoriale, à vérifier avec la photo et les pièces :** « Cascade joue sur la longueur : une pièce mobile attire le regard, les autres laissent de l'espace autour. Reprenez l'ensemble ou gardez un seul point de mouvement pour une composition plus légère. » Ne pas inventer l'emplacement exact avant observation de la photo.

## Les trois pages demandées : insertion dans l'existant

### Guide des tailles

URL existante documentée : `/pages/guide-des-tailles`, template `templates/page.guide-tailles.json`, section `sections/guide-tailles.liquid`, contenu dans le snippet unique.

**Ne pas multiplier les articles.** Refaire la page structurante : 1) identifier le type de pièce ; 2) mesurer jauge/longueur/diamètre ; 3) séparer dimension décorative de l'embout et longueur de barre ; 4) vérifier les données déjà connues ; 5) acheter l'ensemble utile. Ajouter des schémas légendés réellement cotés et un cas embout + barre. Conserver une version contextuelle courte au moment du choix et l'accès au guide complet sans perdre la composition.

Le guide actuel ne distingue pas assez la **taille de tête d'embout** de la longueur de tige, alors que le Composer demande explicitement « Taille de la tête de l'embout » (`ChoixTaille.jsx:24`). C'est une priorité pédagogique, directement liée au produit différenciant.

### Guide des emplacements

**Confirmé :** aucun template dédié de guide d'emplacements repéré dans `templates/`. Le référentiel d'emplacements du Composer et ses libellés sont disponibles.

**Limite :** une page de contenu Shopify générique pourrait exister côté admin sans template dédié ; absence de template ne signifie pas preuve d'absence live.

**Recommandation :** une seule page pérenne `/pages/guide-des-emplacements` (proposition d'URL, pas route confirmée) avec image d'oreille cliquable **et** liste textuelle accessible. Neuf zones anatomiques, onze points dans le Composer car le lobe est subdivisé en 1/2/3. Éviter de présenter ces trois points comme trois anatomies différentes. Garder « hélix avant », « anti-tragus » et les identifiants existants.

Chaque fiche d'emplacement : repère anatomique clair, familles représentées dans le catalogue Odelina, effet dans une composition, mesure à vérifier, lien vers les pièces correspondantes, lien vers le Composer. Pas de taille universelle, pas de douleur ou délai de cicatrisation affirmés, pas de promesse qu'un emplacement convient à toutes les oreilles.

**Lien contextuel conseillé :** « Où se situe le conch ? » dans l'aide d'un emplacement du Composer. L'ouverture doit conserver la composition et permettre de reprendre exactement au même point. « Composer depuis cet emplacement » avec préselection est une évolution à implémenter ; le code actuel n'établit pas ce deep link.

### Entretien des bijoux

**Confirmé :** contenu actuel = un paragraphe dans l'accordéon produit (`templates/product.json:19`) et deux phrases FAQ (`templates/page.faq.json:137`). Aucun template dédié entretien repéré.

**Recommandation :** une page pérenne `/pages/entretien-des-bijoux` (URL proposée) et un résumé produit relié. Rubriques : nettoyer un bijou porté sur un perçage cicatrisé ; rincer/sécher ; manipuler et ranger une petite pièce ; surveiller vissage/fermeture sans forcer ; traiter une pièce endommagée ; comprendre que nettoyer n'est pas stériliser. Les produits, outils ou fréquences spécifiques doivent être validés avec les pièces et recommandations fournisseur, particulièrement pour la finition PVD et les sertissages. Ne pas publier un protocole de plaie.

**Lien au différenciant :** « Garder sa composition belle et pratique » : distinguer éléments mobiles, petites pièces démontables, ordre de manipulation et rangement par composition. Un rappel d'entretien après achat est plus utile qu'un nouveau flux d'articles ; aucun envoi automatique n'a été créé par l'audit.

## Le meilleur axe UX : des sets à la personnalisation

### Friction prouvée dans le template

Les quatre sets configurés Cascade, Constellation, Souveraine et En fleurs ont tous un libellé « Voir le set » mais `link` vide (`templates/page.mise-en-scene.json:158`, `:178`, `:196`, `:214`). Le composant ne rend le bouton que si lien et libellé sont présents (`sections/stacks.liquid:173`). Leur liste de pièces renvoie aux fiches produits ; elle ne précharge pas le set dans le Composer.

**Implication :** l'inspiration et le Composer sont côte à côte, mais la continuité « cette composition → ma version » n'est pas établie par ce code. C'est un axe prioritaire, cohérent avec la singularité d'Odelina et plus utile qu'ajouter des pages catalogue.

### Évolution proposée, pas capacité existante

1. Chaque set éditorial porte une affectation bijou → emplacement → finition → variante ; le seul `product_list` actuel ne suffit pas à décrire un set du Composer.
2. CTA principal « Personnaliser cette composition » charge ces affectations dans le Composer ; secondaire « Voir les pièces » garde le parcours actuel.
3. La cliente retire les points qui ne correspondent pas à son oreille et remplace les pièces librement. Ne pas simuler que la composition valide l'anatomie ou l'ajustement.
4. Les guides s'ouvrent au moment du doute : emplacement depuis le point concerné, taille depuis la modale, entretien depuis la fiche et la FAQ.
5. Le total est explicitement la somme des pièces, sans remise de set inventée. Les barres nécessaires doivent être expliquées et choisies ; ne pas suggérer qu'un set d'embouts suffit systématiquement à équiper l'oreille.

Les URL partagées `?c=` sont déjà une base de représentation de composition, mais il faut vérifier le format de sérialisation et la qualité des données éditoriales avant de transformer ce mécanisme en lien marchand pérenne. Pas de publication ni de développement fait ici.

### Points de choix à rendre plus clairs sans alourdir

- Une taille unique n'est pas une taille universelle ; le texte doit le dire là où aucune modale ne s'affiche.
- « Compatible » signifie présent dans la sélection catalogue pour cet emplacement ; pas validation personnalisée de l'oreille. Ajouter une explication courte au bon endroit plutôt qu'un avertissement répétitif partout.
- Les bijoux épuisés sont essayables, mais exclus du panier (`Recap.jsx:140`). Tester la compréhension d'un récap contenant du stock et de la rupture : le total affiché est le total de la composition, le bouton dit « Tout ajouter au panier ». Proposition à tester : annoncer le nombre de pièces réellement ajoutables et le sous-total concerné, sans modifier la décision d'essayage libre.
- « Mes créations », « concepteur », « Composer », « composition », « ear stack » et « set » coexistent. Préférer dans l'interface « Composer mon oreille » pour l'action et « ma composition » pour le résultat ; conserver les noms de routes requis et « Mises en scène » comme collection éditoriale si souhaité.
- Le lien de la fiche vers le Composer ne transporte pas explicitement le bijou (`sections/product.liquid:572`, `templates/product.json:18`). « Essayez ce bijou avec les autres » (`locales/fr.default.json:217`) peut donc promettre une arrivée contextualisée que le lien générique ne garantit pas. Vérifier en navigateur ; envisager un départ avec ce bijou après choix d'emplacement.

## Accessibilité et mobile : constats source et tests nécessaires

**Bonnes bases confirmées :** cibles de 44 px sur les marqueurs, repères nommés dans le DOM, état sélectionné, modale taille native, guide natif, safe areas iOS prévues dans le CSS (`composer/src/styles.css:2025`), états non fondés sur la couleur seule (`composer/src/components/Oreille.jsx:18`). Ne pas présenter l'existant comme dépourvu de ces éléments.

**Risque à tester :** le récap est un `<aside role="dialog" aria-modal="true">`, avec Échap mais sans piège de focus, déplacement initial de focus ni restitution de focus repérés dans `Recap.jsx` ou `app.jsx` (`Recap.jsx:49`, `:61`). Il peut laisser la navigation clavier sortir du tiroir. Tester au navigateur avant d'annoncer une non-conformité mesurée ; prévoir un dialogue natif ou une gestion du focus complète lors de l'implémentation.

**À tester aussi :**

- Ouvrir la modale taille puis le guide, fermer le guide, retrouver la taille choisie et le bouton de validation ; conservation du focus, Échap et absence de double scroll.
- Au téléphone 360/390 px, lire et utiliser le guide sans perdre la position de l'oreille ni de la composition. Le tableau actuel possède un scroll local prévu (`snippets/guide-tailles.liquid:262`), ce qui ne prouve pas sa facilité de lecture.
- À 200 % de zoom, utiliser les points serrés et la liste alternative d'emplacements ; vérifier qu'aucun élément flottant masque une commande.
- Distinguer les onze repères à l'écran et au lecteur d'écran ; vérifier qu'un point occupé annonce aussi son bijou lorsque pertinent.
- Tester cinq tâches sur un petit échantillon de clientes, dont des personnes peu familières des noms : trouver son emplacement, distinguer jauge/longueur/décor, partir d'un set, remplacer une pièce, choisir les composants nécessaires. Les taux et seuils de réussite sont à définir avant test ; aucun résultat utilisateur n'est disponible.

## Pas de blog, pas de forum

**Confirmé :** le template Mises en scène inclut une section `journal` configurée sur le blog `journal` et présente dans son ordre (`templates/page.mise-en-scene.json:249`, `:266`). Le composant ne l'affiche que s'il existe au moins un article (`sections/journal.liquid:14`). Des templates `blog.json` et `article.json` existent.

**Conclusion correcte :** présence de code de blog, visibilité réelle non prouvée. Ne pas affirmer qu'un journal est affiché live sur cette seule base. Recommandation : retirer/désactiver le bloc éditorial dans la configuration du thème lors de l'implémentation demandée et structurer les trois guides comme pages d'aide stables. Rien dans la demande ne justifie créer un flux d'articles ou un forum.

## Contraintes de projet à respecter dans les recommandations

Document interne `Contexte-projet.md` lu pour l'audit :

- Compte obligatoire pour **enregistrer** ; partage par lien accessible sans compte. Écriture depuis le thème depuis le 17/10 (`Contexte-projet.md:97`, `:99`). Ne pas promettre de sauvegarde anonyme ou locale existante ; ne pas rouvrir la décision de compte.
- Changer `/pages/compte`, `/pages/mes-creations` ou le domaine principal casse les URI de rappel du compte si l'admin n'est pas aligné (`Contexte-projet.md:99`). Recommander des libellés clairs sans renommer les routes au hasard.
- Embouts vendus sans barre ; la barre est un produit séparé. Filetage interne 0,9 mm ; ne pas conclure à une compatibilité intermarque universelle (`Contexte-projet.md:43`, guide `:189`).
- Jauge de la gamme 1,2 mm ; pas de nouveau sélecteur 1,0/1,6 fictif.
- Pas de remise de set au MVP, pas de 3D/AR, pas d'upload d'oreille, pas de galerie publique et pas de wishlist (`Contexte-projet.md:137`, `:309`). Les évolutions spéculatives ne doivent pas prendre le pas sur les contenus et la continuité des sets.
- Descriptions produit : détail visible concret puis données techniques, pas d'adjectif commercial sans information (`Contexte-projet.md:66`). Très bon principe à étendre aux compositions éditoriales.
- Pas de protocole de cicatrisation ; entretien du bijou sur piercing cicatrisé, renvoi au perceur pour le reste (`Contexte-projet.md:242`).

## Ordre recommandé pour la suite

**P0 éditorial :** supprimer les fausses certitudes sur la jauge, la carte bancaire et le gonflement ; harmoniser PVD et conditions de retour ; aligner le guide et les hints avec la modale de taille ; vérifier les termes matière/pierres.

**P1 utile à l'achat :** trois pages d'aide stables reliées aux gestes du Composer ; aide contextuelle courte ; descriptions de sets concrètes ; contrôler ensemble embouts/barres/tailles.

**P1 différenciation :** définir le modèle de données des sets et créer le parcours « Personnaliser cette composition ». Mesurer la réussite de ce parcours et l'utilisation des guides, après implémentation et selon le dispositif de mesure consenti.

**P2 qualité UI :** corriger après vérification la gestion du focus du récap, la lecture sur petit écran, la clarté des ruptures et la contextualisation fiche → Composer.

Ces actions sont des propositions pour le dossier de veille. Aucune n'a été implémentée ni publiée pendant cet audit.

## Charte réellement implémentée : base conseillée pour les PDF et futures pages

La source actuelle est `snippets/css-variables.liquid`, explicitement prioritaire sur les anciennes valeurs de la charte v1.1 (`:5–12`). Les valeurs anciennes du contexte ne doivent pas être reprises comme l'état de l'interface.

| Élément | Valeur présente dans le code | Référence |
|---|---|---|
| Encre / texte principal | `#211B16` | `snippets/css-variables.liquid:23` |
| Fond crème | `#FAF6F0` | `:25` |
| Surface sable | `#F1E9DE` | `:26` |
| Texte secondaire / tertiaire | `#4A4138` / `#8A8073` | `:29` |
| Champagne d'accent | `#C7A567` | `:37` |
| Bouton primaire | encre ; champagne réservé aux accents | `:41` |
| Titres H1/H2 | Fraunces, graisse 300 | `:85`, `assets/critical.css:95` |
| Corps / UI / autres titres | Manrope | `:86`, `assets/critical.css:113` |
| Corps | 15,5 px ; interligne 1,7 | `:99`, `:108` |
| Corps dense / UI / label / méta | 13,5 / 12,5 / 11,5 / 10,5 px | `:100` |
| H1 mobile / desktop | 36 / 58 px | `:95`, `:192` |
| H2 mobile / desktop | 30 / 44 px | `:96`, `:193` |
| Rayons | 4 / 5 / 8 / 10 / 12 / 20 px selon composant | `:142` |
| Ombres | présentes, teinte encre ; plusieurs niveaux | `:152` |
| Transitions | 200 / 400 ms, ramenées à 0 avec réduction des animations | `:160`, `:202` |
| Largeur de lecture | 68 caractères environ (`68ch`) | `:183` |
| Point de rupture principal | 750 px | `:190` |
| Cible tactile | 44 px | `:170` |

**Implication UI :** les guides peuvent être dessinés avec une colonne de lecture calme, des schémas sobres et une aide contextuelle en tiroir, en restant dans ce système. Les petits corps 10,5–13,5 px ne doivent pas recevoir les explications décisives de choix de taille ; vérifier la lisibilité et les contrastes, particulièrement le champagne sur crème. Aucun contraste n'a été mesuré ici.

**Règles éditoriales à conserver :** vouvoiement direct, formulations utiles et concrètes, pas de point médian ; « titane ASTM F136 » pour la matière ; « Titane naturel » et « Couleur dorée » comme choix courts ; « titane, finition PVD couleur dorée » dans les explications ; « hélix avant » et « anti-tragus » dans la navigation ; « jauge » toujours expliquée par « épaisseur de la tige ». Les libellés d'action à l'infinitif sont très présents (« Composer mon oreille », « Ajouter », « Choisir », « Poser », « Retirer », « Modifier »). Les exceptions et divergences actuelles sont documentées plus haut ; elles ne doivent pas devenir le ton modèle.

Le nom « Mises en scène » est au pluriel ; son URL reste volontairement `/pages/mise-en-scene` au singulier (`Contexte-projet.md:92`). Les familles publiques sont embout / anneau / barre courbée ; ne pas réintroduire « charms », « threadless », ni une quatrième famille fictive pour remplir une grille éditoriale.

## Cartographie des destinations repérées

Ce tableau décrit les routes référencées dans la configuration ou les sources. La disponibilité publique exacte doit être confirmée par les visites live réalisées par l'équipe de veille.

| Destination | Route connue ou documentée | Source |
|---|---|---|
| Accueil | `/` | template `templates/index.json` |
| Les pièces | `/collections/les-pieces` | `Contexte-projet.md:40` et `:1134` |
| Mises en scène | `/pages/mise-en-scene` | `Contexte-projet.md:92`, template `page.mise-en-scene.json` |
| Composer / Mes créations | `/pages/mes-creations` | `templates/index.json:166`, `templates/product.json:18` |
| Guide des tailles | `/pages/guide-des-tailles` | `snippets/guide-tailles.liquid:4`, `templates/product.json:16` |
| FAQ | `/pages/faq` | `Contexte-projet.md:1536`, template `page.faq.json` |
| Contact | `/pages/contact` | `snippets/guide-tailles.liquid:182`, template `page.contact.json` |
| Compte | `/pages/compte` | `Contexte-projet.md:99`, template `page.compte.json` |
| Fiche bijou | `/products/<handle>` | `Contexte-projet.md:40`, template `product.json` |
| Panier | `/cart` | destination Shopify et template `cart.json` |
| Recherche | `/search` | `snippets/header-utility-links.liquid:23` |
| Expédition | `/policies/shipping-policy` | `templates/page.faq.json:97` |
| Retours | `/policies/refund-policy` | `templates/page.faq.json:117` |
| Guide des emplacements | aucune route dédiée confirmée par le code | futur contenu proposé |
| Entretien des bijoux | aucune route dédiée confirmée par le code | futur contenu proposé |

Les menus sont des ressources Shopify externes : `sections/header-group.json:23` désigne `main-menu` ; `sections/footer-group.json:25`, `:32`, `:39` désignent `footer-boutique`, `footer-aide`, `footer-maison`. Les liens exacts de ces menus ne sont pas versionnés dans ces fichiers. Il serait incorrect de prétendre en avoir audité le contenu à partir du dépôt seul.

Une page générique existe déjà pour les contenus durables : `sections/page.liquid:19`, avec colonne de lecture et sommaire automatique dès trois intertitres via `snippets/document-toc.liquid:36`. L'entretien peut donc s'insérer dans cette base au lieu d'imposer une architecture d'articles. Le guide des tailles a son propre gabarit et ne reçoit pas automatiquement ce sommaire de document : prévoir son sommaire si la page s'allonge.

**Limite de lecture produit :** les 46 descriptions produits évoquées dans l'historique ne sont pas toutes contenues dans ce thème ; `sections/product.liquid:648` affiche `product.description`, fourni par Shopify. L'audit du dépôt établit les principes et composants, pas une relecture exhaustive du catalogue en ligne. La veille doit citer les fiches réellement visitées pour toute appréciation de leur texte.

## Sources reproductibles

Racine immuable du snapshot : `https://github.com/Lykoleen/Odelina/tree/6897d0f74c0d51383a7e15ad6e92d91a4c91503f`.

Exemples de permaliens :

- Guide : `https://github.com/Lykoleen/Odelina/blob/6897d0f74c0d51383a7e15ad6e92d91a4c91503f/snippets/guide-tailles.liquid#L42`.
- Sets éditoriaux : `https://github.com/Lykoleen/Odelina/blob/6897d0f74c0d51383a7e15ad6e92d91a4c91503f/templates/page.mise-en-scene.json#L143`.
- Modale taille : `https://github.com/Lykoleen/Odelina/blob/6897d0f74c0d51383a7e15ad6e92d91a4c91503f/composer/src/components/ChoixTaille.jsx#L20`.
- Tokens actuels : `https://github.com/Lykoleen/Odelina/blob/6897d0f74c0d51383a7e15ad6e92d91a4c91503f/snippets/css-variables.liquid#L23`.

Aucune recommandation de ce rapport ne s'appuie sur l'ancien audit UX du dépôt ; la demande présente est traitée comme une nouvelle analyse. Les décisions d'octobre 2026 ont été privilégiées aux commentaires et spécifications plus anciens lorsqu'ils divergent.
