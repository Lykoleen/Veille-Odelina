# Addendum — entretien chez le fournisseur officiel Perhiasan

Recherche en lecture seule effectuée le **18 octobre 2026**. Aucun compte créé, aucun formulaire envoyé, aucune prise de contact effectuée. Le manuscrit `entretien.md` n'a pas été modifié.

## Résultat utile pour la rédaction

**Dans le périmètre public consulté, je n'ai pas trouvé de consigne Perhiasan autorisant une méthode « eau tiède + savon doux + rinçage + séchage doux » sur ses bijoux en titane, leurs finitions PVD ou leurs ornements en zirconium cubique.** Ce n'est pas une preuve que cette méthode est inadaptée ; c'est une absence de validation publique identifiée pour les références et pages examinées.

Il faut donc distinguer trois niveaux :

1. **Intention interne Odelina établie** : `Contexte-projet.md:612` prévoit un guide d'entretien des piercings cicatrisés avec eau, savon doux et séchage, et une relecture par un perceur avant publication.
2. **Données fournisseur publiques établies** : le site identifie le titane ASTM-F136 sur plusieurs références, une finition PVD sur une fiche, et le zirconium cubique sur une autre.
3. **Méthode d'entretien pour ces composants assemblés** : non documentée dans le périmètre examiné. Les trois informations précédentes ne suffisent pas à la valider.

Le **chiffon doux sec** du manuscrit est lui-même une proposition conservatrice à faire confirmer, et ne doit pas être présenté comme une recommandation officielle Perhiasan retrouvée en ligne.

## Identification du fournisseur et périmètre examiné

Le document interne `Sources-approvisionnement.md` identifie Perhiasan et ses références fournisseur ; la fiche `composer/fournisseurs/perhiasan.json:84` pointe vers l'API publique du domaine **perhiasan-piercing.com**. Aucun document commercial chiffré ni identifiant privé n'est repris dans cet addendum.

Pages et preuves consultées réellement :

| Source officielle | Ce qu'elle établit | Limite pour l'entretien |
|---|---|---|
| [Accueil](https://perhiasan-piercing.com/) et [À propos](https://perhiasan-piercing.com/a-propos/) | Présentation du fournisseur et navigation. | Pas de méthode de nettoyage du bijou repérée. |
| [Contact / FAQ](https://perhiasan-piercing.com/contactez-nous/) | Le lien « FAQ » du pied de page mène ici. Réponses sur livraison, retours, compte professionnel et matériaux. | Aucun conseil eau, savon, PVD, trempage ou fixation des pierres. |
| [LT-0471](https://perhiasan-piercing.com/product/lt-0471/) | Embout distinct de sa barre ; matière affichée titane ASTM-F136 ; deux couleurs. Référence explicitement citée dans les documents Odelina. | Pas de méthode d'entretien ni nature du montage décoratif précisée. |
| [AT-0104](https://perhiasan-piercing.com/product/at-0104/) | Anneau ; titane ASTM-F136 ; couleurs et tailles. Référence citée dans les documents Odelina. | Aucune consigne de nettoyage retrouvée. |
| [Barre labret, LBT-0001](https://perhiasan-piercing.com/product/barre-labret-titane/) | Barre ; titane ASTM-F136 ; tailles et couleurs. Référence du catalogue Odelina. | Aucune méthode de nettoyage retrouvée. |
| [NT-0022](https://perhiasan-piercing.com/product/nt-0022/) | Une fiche fournisseur mentionne explicitement une finition PVD. | Pas de conseil sur entretien ou tenue du revêtement. Référence étudiée pour le composant, pas déclarée comme pièce du catalogue Odelina. |
| [AT-0138](https://perhiasan-piercing.com/product/at-0138/) | Le texte identifie du zirconium cubique baguette avec une base en titane. | Pas de précision sertissage/collage ; aucun protocole de nettoyage. Ne pas généraliser à tous les ornements Odelina. |
| [Aniosafe savon doux](https://perhiasan-piercing.com/product/aniosafe-savon-doux-flacon-de-500-ml/) | Produit d'hygiène et mode d'emploi pour les **mains**. | Ne démontre aucune compatibilité avec un bijou, un PVD ou une colle. Ne pas transformer sa présence au catalogue en prescription pour les bijoux. |
| [Article officiel fournisseur](https://perhiasan-piercing.com/fournisseur-piercing-faire-le-choix-de-la-qualite-au-meilleur-prix/) | Présentation commerciale et des services ; article publié le 09/02/2026, modifié le 10/02/2026 selon l'API publique. | Aucun protocole d'entretien retrouvé ; ses déclarations de certification restent des déclarations fournisseur, pas notre vérification documentaire. |

Les [CGV](https://perhiasan-piercing.com/conditions-generales-de-vente/), l'index des pages, l'index des articles et les sitemaps ont aussi été examinés. L'API publique répertoriait un article lors de cette consultation. La recherche officielle ciblée renvoie :

- `entretien` : aucun résultat ;
- `nettoyage` : matériel professionnel et produits d'hygiène, pas de guide bijoux ;
- `savon` : deux conditionnements du savon pour les mains ;
- `PVD` : fiche NT-0022 ;
- `zircon` : fiche AT-0138.

Cela n'exclut pas une notice papier, une documentation professionnelle sur demande, des informations dans un espace connecté ou des contenus non indexés. Aucun de ces contenus non publics n'a été supposé disponible ou lu.

## Ajustement conseillé au dossier, à décider avant de modifier le manuscrit

Pour rendre la page opérationnelle sans attribuer une consigne inexistante au fournisseur, on peut ajouter au **tableau interne de validation** une ligne explicite :

> Méthode prévue par Odelina : eau tiède, savon doux, rinçage et séchage doux. Faire confirmer son usage sur la pièce complète, particulièrement la finition PVD et le montage de l'ornement. Ne pas publier de fréquence ni de durée de trempage non validée.

La rédaction client de cette méthode pourra être ajoutée **aux seules références confirmées**. Elle devra porter sur un bijou déjà retiré, distinguer nettoyage et stérilisation, et ne pas déclencher un retrait systématique de toute la composition. Si la méthode n'est pas commune à toutes les pièces, afficher les exceptions par bijou plutôt qu'une promesse globale sur le set.

Le fournisseur doit notamment préciser : savon autorisé ou caractéristiques attendues, contact bref ou immersion, eau autorisée, séchage, produits à éviter, tenue du PVD, nature et fixation des ornements. Une pierre dite « zirconium cubique » n'établit pas si elle est collée ou sertie. Une base en titane ne renseigne pas à elle seule la tolérance de la pièce assemblée.

Conserver les libellés Odelina **« Titane naturel »**, **« Couleur dorée »** et, en explication, **« titane, finition PVD couleur dorée »**. Les mots employés sur le site fournisseur ne remplacent pas le canon de la marque. La disponibilité de lots stériles chez un fournisseur ne modifie pas non plus le statut documenté des bijoux Odelina, livrés non stériles.

## Traces de consultation

Toutes les pages de la table ont répondu **HTTP 200** le 18/10/2026. Les URL finales, horodatages UTC, volumes et erreurs éventuelles sont enregistrés dans :

- `reference/perhiasan/fetch-log-discovery.json` ;
- `reference/perhiasan/fetch-log-content.json` ;
- `reference/perhiasan/fetch-log-faq-products.json` ;
- `reference/perhiasan/fetch-log-search.json` ;
- `reference/perhiasan/fetch-log-targeted.json`.

Les copies `.raw` et extractions `.txt` du même dossier permettent de reproduire le constat. Cette recherche ne vaut ni validation du lot Odelina, ni essai de nettoyage, ni avis médical individuel.
