# Odelina : observations en ligne

Observation du 18 octobre 2026. Accès par le mot de passe fourni, conservé uniquement en mémoire pendant les contrôles ; aucune valeur n'est copiée dans les fichiers de recherche. Aucun ajout panier, enregistrement de composition, compte client ou paiement effectué.

## Pages consultées

- Accueil : https://www.odelina.fr/
- Guide : https://www.odelina.fr/pages/guide-des-tailles
- Mises en scène : https://www.odelina.fr/pages/mise-en-scene
- Composer : https://www.odelina.fr/pages/mes-creations

Toutes ces pages ont répondu 200 avec le contenu attendu après authentification. Rendus Chromium 1440×1000 et 390×844 ; captures longues et textes dans ce dossier. Les requêtes GET ont transité par l'API Playwright et le proxy de l'environnement avec TLS vérifié. Les autres requêtes ont été bloquées. Ce contrôle documente lecture et interactions locales, pas une transaction complète ni un test de performance.

## Parcours mobile effectivement exercé

1. Ouverture des onze repères et de la liste d'emplacements du Composer.
2. Choix Lobe 1, puis bouton « Poser Diaméa sur Lobe 1 ».
3. Ouverture d'une fenêtre « Quel diamètre ? », explicite sur le diamètre intérieur. Variantes visibles 8, 10 et 12 mm, avec états de rupture ; ces valeurs sont un instantané, pas une recommandation de taille.
4. Ouverture « Comment mesurer ? », puis fermeture par Échap.
5. Retour à la fenêtre Diaméa / Lobe 1 et aux mêmes options. Le texte de la sélection et la liste sont conservés. Aucune pose ni commande envoyée pendant ce contrôle.

Cette vérification ne mesure pas l'ordre de focus, l'accessibilité exhaustive, le zoom 200 % ou toutes les combinaisons de fenêtres. Le risque de gestion de focus du récapitulatif repéré dans le code reste à tester.

## Constats concordants avec le code

Le guide en ligne présente les trois mesures, le repère de carte bancaire, les valeurs par emplacement et la promesse de taille préremplie signalés dans l'audit source. Le choix réel du Composer passe par une fenêtre de variantes. Les quatre Mises en scène et leurs pièces sont visibles ; les liens observés renvoient aux fiches des bijoux. Aucun bouton d'ouverture directe d'un set préchargé dans le Composer n'a été observé sur cette page.

## Points visuels à conserver / à éprouver

La palette crème et encre, la typographie et la photo d'oreille sont cohérentes. La liste textuelle offre un accès complémentaire aux points. Sur téléphone, le panneau de choix et le total sont importants ; leur chevauchement et leur lisibilité au défilement demandent une recette sur plusieurs tailles d'écran. Une capture longue peut déplacer les éléments fixes : ne pas en déduire seule un défaut de positionnement.
