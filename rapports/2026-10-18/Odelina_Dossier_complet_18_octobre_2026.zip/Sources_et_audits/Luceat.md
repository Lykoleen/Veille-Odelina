# Luceat Piercing — audit contenu et parcours pour Odelina

Date d'observation : **18 octobre 2026**. Périmètre : site public, desktop 1440 × 1000 et mobile 390 × 844 ; pages et fiches listées en fin de document. Aucune inscription, aucun paiement, aucun ajout au panier. Audit éditorial et visuel effectivement réalisé ; captures et textes probants enregistrés dans ce dossier.

## Lecture en une phrase

Luceat rend ses informations d'aide accessibles jusque dans les fiches produits et montre des compositions sur oreille, mais explique peu la méthode de choix : Odelina peut se distinguer en reliant les guides à une composition réellement personnalisable, avec des dimensions comprises et un choix conservé.

## Méthode et limites importantes

- HTML chargé avec TLS vérifié. Chromium ne reconnaissant pas initialement l'autorité du proxy, les requêtes GET du navigateur ont été chargées par Python/urllib avec la confiance TLS système puis transmises au navigateur. **Aucune désactivation de validation HTTPS**. Scripts et images réellement chargés ; seuls requêtes non GET et certains traceurs ont été bloqués. Aucun échec de ressource consigné dans `visual-errors.json`.
- Captures `*-clean.png` : bandeau cookies fermé par refus, défilement pour déclencher les images et animations. Les captures antérieures sans « clean » montrent l'état initial et peuvent comporter des zones pas encore révélées ; utiliser les captures clean pour analyser les mises en page.
- **Le menu final dépend de JavaScript.** Le HTML initial contenait d'anciens liens « Aide » renvoyant tous au blog. Après rendu, le vrai menu « INFOS & GUIDES » fournit des liens directs corrects. Il serait erroné de présenter ces liens initiaux comme des erreurs vécues dans le parcours normal. Le menu final a été ouvert et ses destinations sauvegardées dans `menu-open-links.json`.
- Aucun achat ni test effectif du panier rempli. La présence d'un bouton ou d'une variante ne prouve donc pas le bon fonctionnement de la transaction. Pas de mesure de conversion, de performance ou de test utilisateur.
- Les limites citées concernent les pages observées ; elles ne démontrent pas l'absence de toute fonctionnalité ailleurs sur le site.

## 1. Accès à l'aide : un bon rapprochement de l'information et de l'achat

### Preuves

Accueil : https://luceatpiercing.fr/

Le menu final comporte « BIJOUX », « ACCESSOIRES », « CARTE CADEAU », « COMPOSITIONS », « DERNIÈRE CHANCE » et « INFOS & GUIDES ». Au survol d'« INFOS & GUIDES », l'utilisateur trouve les noms des piercings, le guide de taille, le guide d'entretien, le contact et le blog. Les trois liens pédagogiques conduisent respectivement à :

- https://luceatpiercing.fr/blogs/infos/guide-des-piercings
- https://luceatpiercing.fr/blogs/infos/guide-de-taille
- https://luceatpiercing.fr/blogs/infos/guide-dentretien

Le pied de page relie aussi les guides ; pour les tailles, il conduit à une seconde version, https://luceatpiercing.fr/pages/guide-de-taille, dont le tableau observé est identique. Les fiches LOTUS et DUNE intègrent des accordéons consacrés aux noms de piercing, aux tailles, à l'entretien et au contact. On peut ouvrir le tableau sans quitter le produit.

L'accueil possède des entrées par emplacement, forme et matière. Les cartes d'emplacement montrent une photo d'oreille, les cartes matière distinguent titane ASTM F-136 et acier 316L. Les cartes matière conduisent aux collections dédiées.

### Interprétation

Cette proximité évite d'obliger le client à retrouver une page d'aide après avoir choisi son bijou. En revanche, la duplication du guide de taille sur deux URL crée un risque de maintenance, même si aucune divergence n'a été observée au jour de l'audit. La structure blog est un choix Luceat, pas un besoin à reproduire chez Odelina : trois pages permanentes peuvent fournir le même service.

## 2. Tailles : tableau fourni, pédagogie de mesure limitée

### Preuves

Sources : les deux guides de taille ci-dessus et les accordéons des fiches.

Le guide couvre anti-hélix, anti-tragus, conch, daith, hélix, lobe, narine, nombril, rook, septum et tragus, en séparant les formes barre / anneau / banane lorsqu'elles sont proposées. Trois colonnes : nom de piercing, épaisseur, longueur ou diamètre. Le texte précise que les valeurs sont des standards et varient selon la morphologie.

Exemple reformulé : pour le conch, le tableau distingue la barre et l'anneau et donne plusieurs épaisseurs et longueurs/diamètres. La valeur ne se réduit donc pas à un seul chiffre « taille conch ».

Sur la page consultée, le tableau n'est pas précédé d'une explication illustrée sur la distinction entre épaisseur, longueur utile et diamètre intérieur. Il ne propose pas de protocole de mesure, de résultat personnalisé ou de choix appliqué au produit. La même troisième colonne réunit longueur et diamètre sans schéma associé.

Sur mobile à 390 px, le tableau tient dans la largeur : largeur du document mesurée à 390 px, sans débordement horizontal. Il impose cependant une longue lecture verticale, avec certaines valeurs en retour à la ligne. Une pastille newsletter à gauche chevauche ponctuellement des lignes du tableau dans la capture. Le contraste du texte violet clair d'en-tête paraît discret à l'œil ; aucun ratio de contraste n'a été mesuré.

### Interprétation

Le tableau répond à « quelles dimensions sont souvent rencontrées ? », moins à « comment choisir pour moi ? ». Une information longue peut être complète sur le plan de la liste et encore insuffisante pour la décision. Odelina gagnerait à commencer par le geste de mesure et à ne montrer ensuite que les repères pertinents à l'emplacement et à la forme choisis dans le Composer.

Aucune dimension Luceat ne doit être reprise comme prescription universelle : la réserve morphologique est pertinente, mais ne suffit pas à faire d'un tableau un diagnostic de compatibilité.

## 3. Emplacements : une carte utile, sans véritable aide à la composition

### Preuves

Source : https://luceatpiercing.fr/blogs/infos/guide-des-piercings

L'article, daté du 27 avril 2023, présente une image d'oreille avec des noms placés près des bijoux. Il rappelle qu'un perceur adapte l'emplacement à la morphologie et recommande de consulter un professionnel pour se faire percer. La même carte apparaît dans l'accordéon « Guide de nom de piercing » des fiches produits.

La page observée ne présente pas de fiches détaillées pour chaque zone, de filtre par trous déjà percés ou de transfert d'un emplacement vers une composition personnalisée. L'essentiel de l'information spécifique réside dans l'image ; celle-ci porte un attribut `alt` vide dans le HTML. Il n'existe pas de liste textuelle voisine reprenant les correspondances de la carte sur cette page.

### Interprétation

Luceat aide à nommer une zone, mais accompagne peu le passage de ce vocabulaire à une décision de style et de compatibilité. Pour Odelina, le guide peut devenir une porte d'entrée directe vers les sets et le Composer : sélectionner mes emplacements déjà percés, comprendre quels bijoux sont envisageables, puis personnaliser. Un schéma doit être complété par des boutons ou une liste textuelle accessible ; cliquer sur une petite zone ne doit pas être la seule façon de l'utiliser.

## 4. Entretien : concret et accessible, mais mélange de périmètres

### Preuves

Source : https://luceatpiercing.fr/blogs/infos/guide-dentretien ; texte aussi présent dans les accordéons produits.

Le guide du 27 avril 2023 propose une série de conseils courts avec pictogrammes : nettoyer avant insertion, utiliser eau tiède et savon doux, rincer, éviter chlore et produits cosmétiques, stocker au sec, vérifier le vissage sans forcer. Le titre et les passages sur la sueur et les produits du quotidien rendent le sujet immédiatement reconnaissable.

Le même texte évoque le rinçage au sérum physiologique et le retrait de certains bijoux fragiles avant le sommeil. Il n'explicite pas une séparation entre entretien d'un bijou retiré, nettoyage d'un bijou porté sur un piercing cicatrisé et soins d'un piercing en cours de cicatrisation. Les conseils ne sont pas ventilés par finition, pierre, colle éventuelle, type de mécanisme ou matière. La page contient plusieurs fautes d'accord et maladresses visibles, par exemple dans les formulations sur les précautions avant de dormir ou la vérification du vissage.

### Interprétation et point de vigilance éditorial

Le format actionnable est une bonne base. Le retrait nocturne ne doit toutefois pas être repris sans expliciter le contexte d'un piercing cicatrisé et les indications du professionnel ; la page commerciale n'est pas une source médicale. La mention du sérum physiologique dans un guide bijoux peut aussi entretenir la confusion entre nettoyage de l'objet et soin du corps. Une future page Odelina doit annoncer clairement son périmètre, faire valider les conseils sensibles et adapter les gestes à la documentation réelle des fournisseurs.

## 5. Matières : vocabulaire précis, preuves et limites à mieux encadrer

### Preuves

- https://luceatpiercing.fr/pages/qualite : deux paragraphes consacrés au titane ASTM F-136 et à la finition Gold PVD. L'acronyme PVD est développé ; la page explique la fonction de la finition et la compare à un plaquage classique.
- https://luceatpiercing.fr/collections/titane : texte d'introduction et FAQ sur le titane, ses propriétés et la comparaison avec l'acier. La FAQ avance notamment un effet favorable sur la rapidité de cicatrisation. Aucune source médicale ou pièce documentaire n'est présentée à proximité de cette allégation dans les contenus consultés.
- https://luceatpiercing.fr/collections/acier-inoxydable : introduction plus prudente, présentant l'acier pour divers usages dont certains piercings cicatrisés. Le bas de page affiche un texte de configuration invitant à paramétrer les questions pour cette collection. Ce placeholder est confirmé dans le texte rendu et la capture desktop.

### Interprétation

Nommer une norme et un procédé est plus utile que dire simplement « haute qualité ». Cela doit toutefois s'accompagner de preuves et d'un vocabulaire mesuré. La page « Qualité certifiée » ne montre pas, dans le périmètre consulté, le document correspondant à la certification annoncée. Les promesses de cicatrisation ou de tolérance absolue ne sont pas à reprendre. Le placeholder FAQ est une vraie faiblesse de finition éditoriale, distincte des réserves méthodologiques sur le menu HTML initial.

## 6. Fiches produits et compositions : l'écart intéressant pour Odelina

### Preuves

Sources : https://luceatpiercing.fr/products/lotus et https://luceatpiercing.fr/products/dune

Les fiches combinent photographie, choix or/argent, prix, quantité, ajout au panier et achat immédiat. Un court texte esthétique est suivi d'une liste technique : matière et finition, mécanisme, dimensions, emplacements envisagés. Sur LOTUS, le mécanisme de vissage interne est nommé, avec barre de 8 mm et épaisseur de 1,2 mm. Sur DUNE, un anneau à charnière est décrit ; sa dimension de 10 mm est appelée « longueur », sans préciser dans la phrase s'il s'agit du diamètre intérieur. Les deux fiches observées ont seulement la couleur comme option de variante ; leurs dimensions sont fixes dans la description. Les données publiques `/products/lotus.js` et `/products/dune.js` confirment ces deux options de couleur. Les sélecteurs de dimensions ne sont donc pas à rechercher là où aucune variante n'est proposée.

Sources compositions :

- https://luceatpiercing.fr/collections/idee-de-conception
- https://luceatpiercing.fr/products/flowers
- https://luceatpiercing.fr/products/fresh

Le menu « COMPOSITIONS » donne accès à des idées photographiées sur oreille présentoir. La page collection alterne grands visuels et lien vers les détails. FLOWERS cite Garance et Capucine avec des liens vers leurs fiches, ouverts dans un nouvel onglet ; FRESH cite quatre bijoux. Les textes invitent à s'inspirer pour créer sa propre idée. La fiche FLOWERS rendue ne comporte pas d'action principale permettant d'ajouter ou de personnaliser toute cette composition ; elle montre des recommandations produits en dessous. Les données publiques définissent néanmoins des produits avec prix et variantes couleur ; cela ne suffit pas à prouver un parcours d'achat groupé opérationnel. Aucun test d'ajout n'a été réalisé.

### Interprétation

Luceat réussit l'inspiration visuelle et donne les noms des pièces. L'utilisateur observé doit encore reconstruire son choix entre plusieurs fiches ; Odelina dispose ici d'un axe de différenciation très concret. Chaque set peut expliquer sa logique (pièce centrale, rappel, équilibre), puis ouvrir le Composer avec les références préchargées, les emplacements visibles et les dimensions confirmées une par une. Il s'agit d'aller plus loin sur l'usage propre à Odelina, sans reprendre la direction artistique ou les textes du concurrent.

## Cinq enseignements transposables à Odelina

1. **L'aide au moment du choix.** Conserver trois pages permanentes Tailles, Emplacements, Entretien ; proposer leur version courte dans un panneau du Composer et sur la fiche produit. Fermer l'aide doit rendre à la composition exactement son état précédent.
2. **Faire comprendre avant d'énumérer.** Illustrer séparément épaisseur, longueur utile et diamètre intérieur. Commencer par l'emplacement déjà percé et le type de bijou, puis afficher des repères contextualisés, avec la possibilité « Je ne connais pas ma taille » et une orientation professionnelle.
3. **Transformer la carte en point de départ.** Associer chaque zone à une description simple et à des boutons accessibles : voir les sets adaptés, ou ouvrir le Composer en conservant cette zone. Le guide peut présenter l'harmonie et l'échelle sans promettre de valider l'anatomie.
4. **Distinguer nettoyage et soin.** Rédiger un guide d'entretien des bijoux qui sépare clairement objet, port sur piercing cicatrisé et situations nécessitant l'avis d'un professionnel ; prévoir des consignes selon les matières et finitions réellement vendues. Éviter les promesses médicales.
5. **Expliquer les sets comme une composition.** Sur chaque set, nommer les pièces, leur emplacement envisagé, leurs dimensions et leur rôle visuel. Donner un bouton « Personnaliser ce set » vers le Composer prérempli ; afficher le détail par bijou avant ajout groupé et permettre le remplacement d'une pièce sans recommencer.

## Sources et pièces de preuve

Toutes consultées le 18 octobre 2026. URLs actives au jour de l'observation ; les prix, stocks et interfaces peuvent évoluer.

| Objet | URL | Preuve locale |
|---|---|---|
| Accueil et menu final | https://luceatpiercing.fr/ | `home-desktop-clean.png`, `menu-open-desktop.png`, `menu-open-links.json` |
| Guide taille page | https://luceatpiercing.fr/pages/guide-de-taille | `size.html`, `size-desktop-clean.png`, `size-mobile-clean.png` |
| Guide taille article | https://luceatpiercing.fr/blogs/infos/guide-de-taille | `size-blog.html`, `size-blog.txt` |
| Emplacements | https://luceatpiercing.fr/blogs/infos/guide-des-piercings | `placements.html`, `placements-desktop-clean.png` |
| Entretien | https://luceatpiercing.fr/blogs/infos/guide-dentretien | `care.html`, `care-browser.txt` |
| Qualité | https://luceatpiercing.fr/pages/qualite | `quality.html`, `quality.txt` |
| Titane | https://luceatpiercing.fr/collections/titane | `titane.html`, `titane.txt` |
| Acier | https://luceatpiercing.fr/collections/acier-inoxydable | `acier.html`, `steel-clean.txt`, `steel-desktop-clean.png` |
| LOTUS | https://luceatpiercing.fr/products/lotus | `lotus.html`, `lotus-desktop-clean.png`, `lotus-mobile-clean.png` |
| DUNE | https://luceatpiercing.fr/products/dune | `dune.html`, `dune-browser.txt`, `dune-product.json` |
| Collection compositions | https://luceatpiercing.fr/collections/idee-de-conception | `compositions-clean.txt`, `compositions-desktop-clean.png` |
| FLOWERS | https://luceatpiercing.fr/products/flowers | `flowers.html`, `flowers-desktop-clean.png` |
| FRESH | https://luceatpiercing.fr/products/fresh | `fresh.html`, `fresh-product.json` |

Note de nettoyage de la recherche : un premier essai d'URL supposée `/collections/titane-f136` a répondu 404. Ce n'était pas une destination trouvée dans le menu final ; cette erreur de recherche n'est pas un défaut du site et n'entre pas dans les constats.
