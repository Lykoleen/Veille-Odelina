## Une page de service au rythme de vos compositions

**Diagnostic et recommandation éditoriale.** Dans le thème étudié, l'entretien tient aujourd'hui dans un accordéon produit et deux phrases de FAQ. Une page dédiée peut réunir les réponses, puis alimenter ces résumés. L'absence de template spécialisé ne démontre cependant pas l'absence d'une page générique dans Shopify.

La destination proposée est une page permanente, « Entretien des bijoux », accessible depuis les fiches, la FAQ et le pied de page. Elle ne nécessite ni blog, ni forum, ni calendrier d'articles. Son objectif est concret : aider à préserver les pièces que vous avez choisies ensemble, avec leurs finitions et leurs petits éléments.

**Le lien propre à Odelina.** Un set est une composition à retrouver facilement. Le contenu doit donc expliquer comment identifier chaque pièce, manipuler un embout sans le perdre, distinguer la barre de l'ornement et ranger les bijoux séparément. Il ne doit pas encourager le démontage de toute l'oreille à chaque entretien.

Trois réponses doivent apparaître rapidement : « Quel geste pour mon bijou ? », « Que vérifier avant de le manipuler ? », « Quand demander de l'aide ? ». Une fiche d'entretien liée à la composition pourra ensuite rappeler les informations par pièce ; cette fonction est une évolution proposée, pas une capacité actuelle démontrée.

Le bénéfice recherché est la continuité : composer, porter et prendre soin du même ensemble, avec des explications courtes et cohérentes.

**Références —** Audit du code Odelina, commit `6897d0f`, `templates/product.json:19`, `templates/page.faq.json:137` ; APP, [bijoux cicatrisés](https://safepiercing.org/jewelry-for-healed-piercings/). Consultation : 18 octobre 2026.

<!-- PAGE -->

## Une entrée claire, puis le bon niveau d'aide

**Architecture recommandée.** La page commence par deux entrées textuelles, utilisables sans reconnaître une icône : « Entretenir mon bijou » et « Mon piercing est récent ou me pose question ». Ce choix oriente la lecture ; il ne certifie pas un état de cicatrisation.

La première entrée mène à quatre sections courtes : les gestes simples, la finition et les ornements, les petites pièces et leur rangement, les réponses fréquentes. Un sommaire permet d'aller directement au sujet. Le gabarit générique Odelina possède déjà une base de lecture et un sommaire automatique ; il peut accueillir cette page de service.

**Texte client proposé.** « Cette page concerne l'entretien des bijoux portés sur des piercings entièrement cicatrisés. Les bijoux Odelina sont livrés non stériles. Nettoyer un bijou ne le stérilise pas. »

**Pour la seconde entrée.** « Si votre piercing est récent, encore en cicatrisation ou si vous avez un doute, demandez conseil à votre perceur avant de changer ou de retirer votre bijou. Cette page ne remplace pas ses recommandations. » Aucun protocole de plaie, calendrier de cicatrisation ou produit de soin n'est ajouté ici.

Une alerte distincte peut orienter vers un professionnel de santé en cas de douleur qui augmente, de chaleur, de gonflement ou de malaise. Son libellé doit être relu avant publication.

Depuis une composition, l'aide doit laisser un retour simple vers les pièces choisies, sans transformer la lecture en étape obligatoire.

**Références —** Canon Odelina, `Contexte-projet.md:242`, FAQ `:29`, `sections/page.liquid:19` ; APP, [Aftercare](https://safepiercing.org/aftercare/) ; NHS, [alertes](https://www.nhs.uk/conditions/infected-piercings/). Consultation : 18 octobre 2026.

<!-- PAGE -->

## Les gestes simples — texte client proposé

**Proposition de rédaction à adapter aux consignes confirmées par vos fournisseurs.**

Votre composition réunit parfois plusieurs petites pièces : un embout, sa barre, un anneau ou une barre courbée. Avant de manipuler un bijou, retrouvez sa fiche et vérifiez sa finition ainsi que la présence d'un ornement. Les conseils adaptés à chaque pièce peuvent différer.

Pour un bijou déjà retiré, commencez par le geste le plus simple : essuyez-le délicatement avec un chiffon doux, propre, sec et non abrasif. Ne frottez pas avec insistance et ne cherchez pas à faire disparaître une trace en grattant. Si elle persiste, contactez-nous avant d'essayer un autre produit.

N'utilisez pas de produit ménager, de pâte abrasive ou de désinfectant pour entretenir vos bijoux. Ne les chauffez pas. Un nettoyage à l'eau, un bain ou un appareil de nettoyage demandent des consignes adaptées à la pièce entière, y compris à sa finition et à son décor.

Ne retirez pas vos bijoux par routine pour suivre ces conseils. Même ancien, un piercing peut se resserrer lorsque le bijou est enlevé. Si une pièce résiste ou si vous avez un doute, demandez l'aide de votre perceur ; ne forcez pas.

Pour ranger vos bijoux retirés, gardez les éléments d'une même composition identifiables et séparés afin de limiter les frottements. Si une fermeture ne tient plus, si une pièce paraît abîmée ou si un ornement bouge, demandez conseil avant de la remettre.

**Références —** APP, [bijoux cicatrisés](https://safepiercing.org/jewelry-for-healed-piercings/) et [Aftercare](https://safepiercing.org/aftercare/) ; consignes d'entretien par référence Odelina à confirmer. Consultation : 18 octobre 2026.

<!-- PAGE -->

## La bonne méthode dépend de toute la pièce

**Recommandation interne — validation fournisseur.** La finition, l'ornement et le montage comptent autant que la base en titane. Ce tableau prépare la rédaction ; sa méthode reste à valider pour le catalogue.

| Composant | Base prudente proposée | À confirmer avant publication |
|---|---|---|
| **Titane naturel** | Chiffon doux sec, sans frottement appuyé. | Composition des parties ; compatibilité avec eau et nettoyage. |
| **Couleur dorée** | Chiffon doux sec ; pas de polissage abrasif. | Titane, finition PVD couleur dorée : consignes du revêtement, produits et conditions à éviter. |
| **Ornement** | Manipulation délicate ; aucun trempage présumé compatible. | Nature du décor, pierre ou autre matériau ; sertissage ou collage ; sensibilité à l'eau et aux produits. |
| **Filetage et fermeture** | Manipuler sans forcer ; demander de l'aide si le montage résiste. | Geste adapté, contrôle de fermeture, conduite à tenir en cas de dommage. |

**Règle de rédaction.** Conserver les choix courts « Titane naturel » et « Couleur dorée ». Développer le second en « titane, finition PVD couleur dorée ». Ne promettre ni usage waterproof, ni résistance illimitée de la couleur, ni nettoyage identique pour toutes les pièces.

La mention ASTM F136 exige une documentation matière traçable ; elle ne garantit pas à elle seule le revêtement ou le montage. Une routine commune à un set n'est proposée que si elle convient à chacun de ses composants.

**Références —** Canon Odelina, audit code ; APP, [matières et finitions](https://safepiercing.org/jewelry-for-initial-piercings/) ; [ASTM F136-26](https://store.astm.org/f0136-26.html) ; [Pandora, exemple de consignes différenciées](https://uk.pandora.net/en/blog/how-to-clean-jewellery/). Consultation : 18 octobre 2026.

<!-- PAGE -->

## Des réponses courtes, au bon moment

**Microtextes client proposés.**

**Dois-je retirer toute ma composition pour l'entretenir ?** « Ne retirez pas vos bijoux par routine. Suivez les indications de chaque pièce et demandez conseil à votre perceur si vous devez les enlever ou si un montage résiste. »

**La même méthode convient-elle à tout mon set ?** « Pas nécessairement. La finition et les ornements peuvent demander des précautions différentes. Retrouvez les consignes de chaque bijou avant de commencer. »

**Puis-je faire briller la couleur dorée avec un produit de polissage ?** « N'utilisez pas de produit abrasif. Pour votre bijou, suivez les consignes de la finition PVD couleur dorée ou contactez-nous. »

**L'embout se dévisse-t-il de sa barre ?** « L'embout et la barre sont deux éléments distincts. Vérifiez la fiche de votre modèle et ne forcez jamais pour les séparer. » La rédaction finale doit correspondre au montage réel.

**Parcours après achat — évolution proposée.** Une page récapitulative pourrait réunir, pour chaque pièce achetée, son nom, sa finition, ses dimensions et son lien d'entretien. Les embouts vendus seuls restent clairement distingués de leurs barres ; aucune compatibilité intermarque n'est déduite.

Depuis « Mises en scène » ou le Composer, un lien « Prendre soin de ces bijoux » peut ouvrir l'aide sans effacer la composition. Le retour « Revenir à ma composition » doit retrouver le même état. Aucun envoi automatique ni nouvelle fonction de sauvegarde n'est présumé existant.

**Références —** Odelina, `sections/product.liquid:438`, `composer/src/components/Recap.jsx`, `Contexte-projet.md:43` ; APP, [manipulation](https://safepiercing.org/jewelry-for-healed-piercings/). Consultation : 18 octobre 2026.

<!-- PAGE -->

## Valider les conseils, puis vérifier le parcours

**Avant publication.** Le fournisseur confirme les consignes par référence : matière de chaque composant, finition PVD, nature et fixation du décor, compatibilité avec l'eau et les produits, précautions de fermeture. Une description générique du titane ne remplace pas cette vérification. Sans réponse, conserver le conseil le plus prudent et un contact utile ; ne pas inventer de fréquence ou de durée de trempage.

Le perceur relit la séparation entre entretien du bijou et situation d'un piercing récent, les recommandations de manipulation et l'absence de retrait systématique. Les alertes médicales, si elles figurent sur la page, demandent une formulation et une orientation adaptées au public français.

**Recette éditoriale.** Vérifier que chaque conseil a une portée claire : bijou retiré, pièce complète ou composant. Relire ensemble page, fiche produit et FAQ. Les finitions doivent porter les mêmes noms ; nettoyer ne doit jamais signifier stériliser. Les promesses non documentées et les délais universels sont exclus.

**Recette UX.** Sur téléphone et au clavier, trouver la consigne d'un anneau, distinguer une finition d'un ornement, puis revenir à une composition intacte. Les entrées doivent être nommées, les liens compréhensibles hors contexte, les explications lisibles sans déplier une succession d'accordéons.

Faire essayer ces tâches à quelques clientes peu familières des termes. Définir les critères de réussite avant le test, puis observer les hésitations et ajuster les formulations ; aucune performance utilisateur n'est encore mesurée.

**Livrable attendu.** Une page de service stable, des résumés synchronisés et une matrice fournisseur conservée pour les futures pièces.

**Références —** Audit du code Odelina ; APP, [Aftercare](https://safepiercing.org/aftercare/) ; NHS, [alertes](https://www.nhs.uk/conditions/infected-piercings/). Sources utilisées dans leurs périmètres respectifs. Consultation : 18 octobre 2026.
