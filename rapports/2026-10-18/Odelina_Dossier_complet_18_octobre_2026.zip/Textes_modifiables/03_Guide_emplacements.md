## Reconnaître ses emplacements, puis composer

**Texte proposé pour les clientes**

Vous connaissez l'endroit où vous portez votre bijou, mais pas forcément son nom. Ce guide vous aide à le repérer et à imaginer sa place dans votre composition. Choisissez une zone sur la carte ou retrouvez-la dans la liste : vous accédez aux mêmes explications.

L'oreille représentée sert de repère. La forme, les reliefs et la position des perçages varient d'une personne à l'autre. Un emplacement visible sur l'image ne confirme pas qu'un nouveau perçage est réalisable sur votre oreille. Pour un projet de perçage, demandez conseil à votre perceur.

Dans le Composer, **Lobe 1, Lobe 2 et Lobe 3** désignent trois points d'une même zone. Les autres repères sont Hélix, Hélix avant, Flat, Rook, Daith, Conch, Tragus et Anti-tragus. Vous n'avez pas besoin de les utiliser tous : quelques pièces bien choisies peuvent suffire à construire votre composition.

Avant d'acheter, vérifiez séparément l'emplacement, les mesures du bijou et les éléments vendus ensemble. Le Composer vous aide à visualiser les associations ; il ne mesure pas votre oreille.

**Préconisations internes**

Créer une page permanente, avec carte et liste accessibles au clavier. Conserver les onze identifiants du Composer et regrouper les trois lobes dans une seule fiche. Chaque point ouvre une explication courte, jamais une taille automatique. Sur mobile, garder la liste immédiatement disponible sans imposer un zoom ou un survol.

**Sources — 18/10/2026 :** [Référentiel Odelina, commit audité](https://github.com/Lykoleen/Odelina/blob/6897d0f74c0d51383a7e15ad6e92d91a4c91503f/composer/src/data/emplacements.js#L16) ; [navigation Titanea par zone](https://titanea.fr/piercing-oreille-titane/).

<!-- PAGE -->

## Lobe, Hélix et Hélix avant

**Texte proposé pour les clientes**

**Lobe 1 · Lobe 2 · Lobe 3**

Le lobe est la partie souple, tout en bas de l'oreille. Les trois repères du Composer permettent de répartir vos bijoux le long de cette même zone ; ils ne correspondent pas à trois formes d'oreille différentes.

Dans une composition, le lobe peut servir de point de départ. Une pièce attire le regard, puis des éléments plus discrets prolongent la ligne. Vous pouvez aussi ne garder qu'un seul point.

À vérifier : l'épaisseur de la tige, puis la longueur utile de la barre ou le diamètre intérieur de l'anneau choisi. La taille du décor est une autre mesure.

**Hélix**

L'hélix suit le bord extérieur de l'oreille, principalement dans sa partie haute. Il peut prolonger une composition vers le haut ou créer un rappel avec les bijoux du lobe.

À vérifier : les mesures du bijou et l'espace qu'occupe son décor par rapport aux pièces voisines. La position du trou compte autant que le nom de la zone.

**Hélix avant**

Ce repère se situe sur le bord avant de l'oreille, près du visage, au-dessus du tragus. Il peut apporter un petit accent qui répond au côté opposé de la composition.

À vérifier : les dimensions connues de votre bijou adapté et l'encombrement du décor dans cet espace resserré.

**Préconisations internes**

Afficher les libellés canoniques. Un synonyme peut aider dans le texte, sans remplacer « Hélix avant » dans les commandes.

**Sources — 18/10/2026 :** [Noms et repères Odelina](https://github.com/Lykoleen/Odelina/blob/6897d0f74c0d51383a7e15ad6e92d91a4c91503f/composer/src/data/anchors.js#L56) ; [distinctions hélix/avant/flat](https://titanea.fr/piercing-helix-titane/).

<!-- PAGE -->

## Flat, Conch et Tragus

**Texte proposé pour les clientes**

**Flat**

Le flat correspond à la surface relativement plate dans la partie haute de l'oreille, à l'intérieur du bord de l'hélix. Ce repère aide à situer un décor plutôt qu'une ligne longeant le contour.

Dans une composition, cette zone peut porter le point d'attention principal. Pour conserver un ensemble lisible, laissez de l'espace visuel autour du décor.

À vérifier : l'épaisseur de la tige, la longueur utile de la barre et les dimensions de la tête de l'embout. Un décor plus grand ne signifie pas une barre plus longue.

**Conch**

Le conch se situe dans le creux central de l'oreille, la conque. Il peut ancrer visuellement une composition et relier les éléments du haut à ceux du lobe.

À vérifier : les dimensions du bijou correspondant à votre perçage. Pour un anneau, le diamètre intérieur détermine notamment l'espace entre le point percé et le contour de l'oreille ; une valeur standard ne suffit pas à le choisir.

**Tragus**

Le tragus est la petite avancée de cartilage devant l'ouverture du conduit auditif. Il apporte un accent près du visage, distinct des bijoux disposés sur le bord extérieur.

À vérifier : les mesures du bijou adapté, l'encombrement du décor et les contacts possibles dans vos usages quotidiens, notamment avec les écouteurs.

**Préconisations internes**

Associer chaque fiche à un zoom légendé. N'afficher une sélection de bijoux qu'après vérification des compatibilités du catalogue, variante par variante.

**Sources — 18/10/2026 :** [Définitions des zones](https://titanea.fr/piercing-oreille-titane/) ; [compatibilité Odelina](https://github.com/Lykoleen/Odelina/blob/6897d0f74c0d51383a7e15ad6e92d91a4c91503f/composer/src/lib/compat.js#L72).

<!-- PAGE -->

## Rook, Daith et Anti-tragus

**Texte proposé pour les clientes**

**Rook**

Le rook se situe dans un repli de cartilage de la partie haute et intérieure de l'oreille, au-dessus de la conque. Ce relief se distingue du flat, qui désigne une surface plus plate.

Dans une composition, il peut créer un accent intérieur et laisser le contour extérieur plus léger.

À vérifier : la forme et les dimensions du bijou déjà adapté à votre perçage. Avec une barre courbée, distinguez la longueur utile de la barre de la taille des décors. Si vous ne connaissez pas la mesure, faites-la confirmer.

**Daith**

Le daith correspond au petit repli intérieur au-dessus de l'ouverture du conduit auditif. Il place un élément visuel au cœur de l'oreille et peut devenir le point autour duquel les autres bijoux s'organisent.

À vérifier : les mesures du bijou, son système de fermeture et l'espace occupé par son décor. Pour un anneau, on parle de diamètre intérieur. Le rendu sur une photo n'indique pas la dimension qui vous convient.

**Anti-tragus**

L'anti-tragus est la petite saillie de cartilage située au-dessus du lobe, en face du tragus. Il peut relier visuellement le bas de l'oreille à sa partie intérieure.

À vérifier : les mesures connues pour votre perçage et la place disponible autour de la pièce. Tous les reliefs d'oreille ne se ressemblent pas.

**Préconisations internes**

Ne promettre ni faisabilité anatomique, ni effet santé. Faire relire les repères et illustrations par un perceur avant publication.

**Sources — 18/10/2026 :** [Repérage anatomique](https://titanea.fr/piercing-oreille-titane/) ; [vocabulaire Odelina](https://github.com/Lykoleen/Odelina/blob/6897d0f74c0d51383a7e15ad6e92d91a4c91503f/composer/src/data/emplacements.js#L16).

<!-- PAGE -->

## Relier les guides aux compositions

**Texte client proposé pour le futur parcours**

Une mise en scène vous plaît ? Prenez-la comme point de départ. Vous pouvez en garder l'équilibre, retirer les emplacements que vous n'utilisez pas et remplacer une pièce pour créer votre version.

Vous hésitez sur un nom ? Ouvrez le guide de l'emplacement concerné. Vous y retrouverez son repère, son rôle visuel et la mesure à vérifier avant de poursuivre. Une fois l'explication refermée, reprenez votre composition là où vous l'avez laissée.

Avant l'ajout au panier, relisez chaque pièce : emplacement choisi, finition, mesure et éléments inclus. Un embout vendu seul ne comprend pas sa barre. Le rendu donne une idée de l'association des bijoux ; il ne confirme ni leurs proportions sur votre oreille ni leur ajustement à votre perçage.

**Préconisations internes — évolutions à concevoir**

Le code audité contient déjà les Mises en scène, le Composer, un guide des tailles partagé et le partage de créations par lien. Il ne prouve pas un chargement marchand automatique d'un set dans le Composer.

Proposer un bouton « Personnaliser cette composition », après avoir défini les affectations pièce → emplacement → variante. Prévoir un retour depuis le guide qui conserve le projet et son point sélectionné. Un accès direct préselectionnant un emplacement serait une évolution, pas une fonction existante.

La future route `/pages/guide-des-emplacements` et ses ancres sont des propositions à implémenter. Préserver les routes actuelles du Composer et du compte. La compatibilité catalogue reste distincte d'une validation anatomique.

**Sources — 18/10/2026 :** [Mises en scène](https://github.com/Lykoleen/Odelina/blob/6897d0f74c0d51383a7e15ad6e92d91a4c91503f/sections/stacks.liquid#L130) ; [récapitulatif du Composer](https://github.com/Lykoleen/Odelina/blob/6897d0f74c0d51383a7e15ad6e92d91a4c91503f/composer/src/components/Recap.jsx#L143).

<!-- PAGE -->

## Des mots courts, des choix compréhensibles

**Microtextes proposés pour les clientes**

- Sur la carte : « Choisir un emplacement ».
- Sous la carte : « Préférer la liste des emplacements ».
- Depuis un point : « Où se situe le Conch ? ».
- Pour revenir au projet : « Reprendre ma composition ».
- À côté d'une mesure : « Comprendre cette dimension ».
- Lorsqu'une seule option existe : « Une seule dimension proposée. Vérifiez qu'elle correspond à votre perçage. »
- Pour la compatibilité : « Ce bijou figure dans notre sélection pour cet emplacement. Son ajustement dépend de vos mesures. »
- Si la mesure reste inconnue : « Vérifiez votre fiche de pose ou demandez conseil à votre perceur avant de choisir. »
- Pour un embout : « Embout vendu seul. Barre à choisir séparément. »

**Préconisations internes — validation avant publication**

Faire relire les repères anatomiques. Vérifier les onze points, titres et ancres. Contrôler liens produits et compatibilités par variante ; ne pas supposer de pièces disponibles.

Tester cinq tâches : reconnaître une zone sans jargon, distinguer diamètre et longueur, adapter une mise en scène, consulter une aide puis retrouver son projet, comprendre les composants nécessaires avant l'achat. Ces tests restent à réaliser.

Sur mobile et au clavier, vérifier les cibles de sélection, le focus d'ouverture et de retour, la fermeture des aides et la lecture à 200 % de zoom. La couleur ne doit pas être le seul indice de sélection. Conserver des explications courtes sur la carte et le détail dans la fiche, sans multiplier les avertissements.

**Sources — 18/10/2026 :** [dialogue de taille](https://github.com/Lykoleen/Odelina/blob/6897d0f74c0d51383a7e15ad6e92d91a4c91503f/composer/src/components/ChoixTaille.jsx#L20) ; [points accessibles](https://github.com/Lykoleen/Odelina/blob/6897d0f74c0d51383a7e15ad6e92d91a4c91503f/composer/src/components/Oreille.jsx#L128).
