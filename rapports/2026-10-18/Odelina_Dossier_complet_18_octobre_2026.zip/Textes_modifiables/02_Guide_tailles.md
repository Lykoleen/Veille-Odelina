## Une bonne base, des certitudes à retirer

Le guide existe déjà sous une forme utile : une page dédiée, des schémas et une seule source éditoriale, partagée avec la fiche produit et le Composer. Il faut améliorer cette base et préserver l'accès à l'aide pendant la composition.

**La priorité : passer d'une taille supposée à une mesure vérifiée.** Le texte actuel laisse déduire une jauge de 1,2 mm selon le lieu de perçage, puis propose de la reconnaître à côté d'une carte bancaire. Ces indices ne permettent pas de confirmer une dimension précise. Ils doivent disparaître.

Le tableau par emplacement et la promesse de taille préremplie sont également à revoir. Depuis octobre, le Composer demande une taille lorsqu'il existe plusieurs choix ; il ne conseille pas de taille anatomique. Le conseil « 8 mm si le perçage est gonflé » doit laisser place à une vérification par le perceur.

Enfin, le guide explique trois mesures alors que le Composer peut demander une quatrième : **la dimension de la tête d'embout**. Cette confusion touche directement le parcours d'achat : choisir un décor ne choisit pas sa barre.

La refonte doit donc produire une aide plus précise, immédiatement compréhensible, avec quatre mesures distinctes et des mots cohérents entre guide, variantes et Composer. Elle ne demande ni blog ni forum.

*Sources : dépôt Odelina, commit 6897d0f, `snippets/guide-tailles.liquid`, l. 42–52, 131–175, 229–235 ; `composer/src/components/ChoixTaille.jsx`, l. 20–24 et 31–35. Lecture du code, pas test utilisateur.*

<!-- PAGE -->

## Quatre mesures, un parcours simple

La page commence par une question concrète : **« Quel bijou souhaitez-vous choisir ? »** Trois entrées suffisent : anneau, embout, barre. Elles conduisent aux sections utiles sans masquer les autres explications.

Les quatre mesures occupent ensuite quatre cartes, avec un schéma légendé et une phrase chacune :

- **Jauge :** épaisseur de la tige qui traverse le perçage. Elle doit correspondre à votre perçage existant.
- **Longueur utile de la barre :** partie qui traverse le tissu, hors décor et hors extrémités. Pour une barre courbée, utiliser le schéma de mesure correspondant au produit.
- **Diamètre intérieur :** ouverture de l'anneau, mesurée entre ses bords intérieurs. Le diamètre extérieur ne décrit pas cette taille.
- **Dimension de la tête d'embout :** taille de la partie décorative visible. Elle influence le rendu de la composition ; elle ne donne pas la longueur de la barre.

La suite répond dans cet ordre : où retrouver ses mesures, comment lire une cote, comment associer embout et barre, que vérifier avant de commander. Un sommaire court et des liens d'ancrage rendent la page facile à parcourir sur téléphone.

Dans le Composer, une aide courte montre d'abord **la seule mesure demandée**, puis donne accès au guide complet. La composition et le choix en cours doivent rester intacts à la fermeture. Le tableau « emplacement = millimètres » laisse place à des exemples de lecture des mesures, sans taille universelle par zone.

*Sources : `snippets/guide-tailles.liquid`, l. 56–97 ; `sections/composer.liquid`, l. 103–118 ; `ChoixTaille.jsx`, l. 20–24 et 106–108. Architecture proposée, à concevoir et tester.*

<!-- PAGE -->

## Le texte à proposer aux clientes

**Choisir votre bijou, sans deviner sa taille**

Un bijou peut convenir au style de votre composition sans avoir les dimensions adaptées à votre perçage. Avant de commander, vérifiez les mesures du bijou que vous portez confortablement ou demandez conseil à votre perceur.

**Commencez par l'épaisseur de tige.** Les bijoux Odelina sont proposés en jauge 1,2 mm. Cette mesure décrit notre gamme ; elle ne permet pas de connaître la jauge de votre perçage. Votre fiche de pose, l'emballage d'un bijou identifié ou votre perceur peuvent vous aider à la confirmer.

**Pour un anneau, regardez le diamètre intérieur.** Il correspond à l'espace libre au centre du bijou. Deux anneaux qui semblent proches en photo peuvent avoir des diamètres différents.

**Pour une barre, vérifiez sa longueur utile.** Elle dépend de votre anatomie et de votre perçage. Le nom d'un emplacement, comme « hélix » ou « conch », ne suffit pas à choisir cette longueur.

**Pour un embout, distinguez décor et barre.** La dimension de la tête vous aide à choisir l'effet visuel. L'embout est vendu seul : il lui faut une barre compatible, dont la jauge et la longueur se vérifient séparément.

Vous hésitez ou ne connaissez pas vos mesures ? Faites-les vérifier avant de commander. Si la zone est gonflée, douloureuse ou si le bijou serre, demandez l'avis de votre perceur avant tout changement.

*Base éditoriale proposée ; validation produit nécessaire. Sources : `snippets/guide-tailles.liquid`, l. 65–95 et 187–201 ; `templates/page.faq.json`, l. 49–57 ; `ChoixTaille.jsx`, l. 20–24.*

<!-- PAGE -->

## Mesurer sans transformer l'aide en contrainte

**1. Cherchez d'abord une mesure déjà fiable.** Consultez la fiche de pose, la facture détaillée ou l'emballage du bijou. Vérifiez à quoi correspond chaque chiffre : jauge, longueur, diamètre ou décor. Un simple « 8 mm » sans contexte ne suffit pas.

**2. Comparez avec une pièce adaptée.** Si vous disposez déjà d'un bijou retiré, identifié et adapté à votre perçage, vous pouvez en relever les dimensions. Ce guide ne vous demande pas de retirer un bijou porté pour obtenir une mesure. Votre perceur reste l'interlocuteur utile si la mesure n'est pas accessible ou sûre.

**3. Utilisez le bon repère.** Sur une barre droite, mesurez la partie utile hors décor et extrémités. Pour un anneau, mesurez l'ouverture intérieure. Pour une pièce courbée ou un décor irrégulier, suivez un schéma produit validé. Une règle graduée peut aider pour longueur et diamètre ; elle ne confirme pas précisément une jauge.

**4. Séparez l'embout de sa fixation.** Un embout Odelina se visse sur une barre de jauge 1,2 mm à filetage interne 0,9 mm. Ces deux chiffres désignent des fonctions différentes. Une barre achetée ailleurs n'est pas automatiquement compatible, même si sa jauge est identique.

**5. Contrôlez le contenu de la commande.** Avez-vous déjà une barre compatible ? Sinon, choisissez-la séparément. Ne forcez jamais un vissage qui résiste. Le guide peut vous aider à lire les cotes ; il ne valide ni votre anatomie ni un montage entre marques.

*Sources : `snippets/guide-tailles.liquid`, l. 105–127 et 187–201 ; `locales/fr.default.json`, l. 210–213. Schémas de mesure et compatibilités à valider sur les références vendues.*

<!-- PAGE -->

## Les bons mots au moment du choix

Une phrase contextualisée aide davantage qu'une longue mise en garde répétée. Les propositions suivantes doivent s'afficher au moment où la cliente prend la décision correspondante.

**Dans la modale d'un anneau**

« Quel diamètre intérieur ? »

« Mesurez l'ouverture de votre anneau actuel ou faites vérifier cette mesure par votre perceur. »

**Pour la tête d'un embout**

« Quelle dimension de décor ? »

« Cette mesure concerne la partie visible. La barre est vendue séparément. »

**Lorsqu'une option apparaît déjà sélectionnée**

« Vérifiez votre mesure avant de poser. La sélection affichée n'est pas une recommandation pour votre oreille. »

La première taille en stock est aujourd'hui sélectionnée dans la modale. C'est une facilité de navigation, jamais une preuve que la taille convient. Une taille unique demande la même vérification ; elle ne doit pas être présentée comme « adaptée à toutes ».

**À côté de l'aide**

« Comment mesurer ? » ouvre le guide sans quitter la composition. Sa fermeture doit rendre le choix précédent, y compris si l'aide s'ouvre au-dessus de la modale.

**Au moment de commander**

« Embout seul : avez-vous une barre compatible ? » La réponse ouvre le choix utile, sans ajout automatique. Le récapitulatif distingue clairement dimension décorative, diamètre intérieur et longueur lorsqu'elles sont connues ; une valeur « 6 mm » isolée reste ambiguë.

Le hint d'accueil doit suivre le fonctionnement actuel : « Choisissez un bijou, puis sa taille si plusieurs options sont disponibles. »

*Sources : `ChoixTaille.jsx`, l. 21–35 ; `Conseils.jsx`, l. 14 ; `Recap.jsx`, l. 131–138 ; `sections/product.liquid`, l. 438–465. Microtextes proposés, à tester.*

<!-- PAGE -->

## Les conditions d'une publication de qualité

La page est prête lorsque textes, données et interactions concordent. Vérifier un anneau à plusieurs diamètres, un embout à plusieurs décors, un embout à taille unique et une barre.

**Données produit.** Chaque valeur de taille indique ce qu'elle mesure. La dimension décorative reste distincte de la longueur de barre et de l'échelle visuelle du Composer. Les emplacements autorisés sont vérifiés variante par variante dans le catalogue ; ils ne deviennent pas des conseils anatomiques. La disponibilité affichée correspond à la finition et à la taille choisies.

**Contenu.** Aucun passage ne déduit la jauge du pays, du nom d'emplacement ou d'un repère visuel approximatif. Les schémas précisent les points de mesure. Les instructions sur pièces courbées et filetages sont validées par la personne responsable du catalogue. Aucune promesse médicale ou de stérilité n'est introduite.

**Interaction.** Sur téléphone, au clavier et avec zoom, la cliente ouvre l'aide, la referme et retrouve sa composition, sa taille et un focus cohérent. Les tableaux et schémas restent lisibles. Les textes essentiels ne sont pas réduits au corps des légendes.

**Compréhension.** Faire essayer cinq tâches : retrouver une mesure, différencier décor et barre, identifier un diamètre intérieur, reprendre une composition et choisir les composants nécessaires. Recueillir les hésitations ; ne pas présenter une impression interne comme un résultat utilisateur.

**Publication.** Conserver la source unique et l'URL existante. Aligner les trois accès avant mise en ligne ; aucun changement public n'a été réalisé ici.

*Sources : `snippets/composer-catalogue.liquid`, l. 99–106 ; `sections/product.liquid`, l. 740 ; `sections/composer.liquid`, l. 115 ; `css-variables.liquid`, l. 99–103. Recette proposée, à exécuter après implémentation.*
