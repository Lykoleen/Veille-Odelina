## Le cap : rendre chaque composition compréhensible

**La meilleure occasion pour Odelina est de relier l'inspiration à un choix personnel : comprendre un set, l'adapter dans le Composer et vérifier les pièces nécessaires.** Les concurrents donnent beaucoup d'informations. L'avantage ne viendra pas d'un plus grand nombre de pages, mais d'une aide plus claire au moment de choisir.

### Cinq décisions recommandées

1. **Consolider le guide des tailles existant.** Expliquer quatre mesures distinctes : épaisseur, longueur utile, diamètre intérieur et dimension du décor. Retirer les raccourcis qui donnent une fausse certitude.
2. **Créer un guide des emplacements orienté composition.** Une carte, une liste accessible et de courtes fiches de zone ; chaque entrée aide à comprendre un rendu et mène vers les pièces ou le Composer.
3. **Réunir l'entretien dans une page permanente.** Donner les gestes adaptés aux bijoux réellement vendus, distinguer finition et ornement, puis séparer nettement entretien de l'objet et situation d'un piercing récent.
4. **Faire des Mises en scène un point de départ modifiable.** Le bouton « Personnaliser cette composition » est une évolution à construire : il doit transporter les bijoux, emplacements et variantes nécessaires.
5. **Garder une seule information de référence.** La page complète, l'aide courte, la fiche produit et le récapitulatif doivent parler des mêmes dimensions avec les mêmes mots.

> **Le résultat recherché :** « Je comprends ce que j'achète, je sais ce que je peux modifier et je retrouve ma composition. » Aucun gain de conversion n'est encore mesuré.

*Base : observations des quatre concurrents, site Odelina et dépôt au commit 6897d0f. Propositions à concevoir et à tester ; aucune modification publiée.*

<!-- PAGE -->

## La comparaison, sans classement artificiel

L'audit porte sur les accueils, guides, fiches et compositions des quatre sites. Les interfaces ont été examinées sur ordinateur et sur mobile à 390 px. Les constats sont datés du **18 octobre 2026**.

| Site | Apport éditorial le plus utile | Friction observée | Enseignement Odelina |
|---|---|---|---|
| **By Les Audacieuses** | Fiche technique et aide de taille contextuelle. | Guides dispersés ; tableau en image ; nouveau PDF derrière un email. | Aide ouverte, courte et lisible au moment du choix. |
| **Nébuleuse** | Dimensions détaillées, photographies portées et pièces du set identifiées. | Le tableau explique les zones davantage que la mesure. | Relier chaque pièce à son rôle, sa zone et sa dimension. |
| **Luceat** | Guides dans la fiche et inspirations photographiées. | Mesures peu illustrées ; contenu parfois générique. | Expliquer le geste puis permettre l'adaptation du set. |
| **Titanea** | Réponses approfondies et aide près du sélecteur. | Accumulation et contradictions internes de certaines valeurs. | Une réponse utile d'abord ; un référentiel unique ensuite. |

### Ce que cette étude ne prétend pas établir

Pas de test utilisateur, d'audit WCAG complet, de mesure de conversion ou de performance terrain. Aucun achat, compte concurrent ou panier rempli n'a été créé. Les certificats matière n'ont pas été contrôlés.

Les modules quiz et Mix and Match des Audacieuses n'ont pas été parcourus intégralement. Il serait donc faux de conclure que les concurrents ne proposent aucune personnalisation. La différenciation proposée décrit ce qu'Odelina peut rendre plus explicite dans les parcours étudiés.

*Lecture et rendus Chromium, TLS vérifié. URL et limites détaillées dans les sources et notes jointes.*

<!-- PAGE -->

## By Les Audacieuses : l'aide au bon endroit

### Ce qui fonctionne

La fiche **Oser** sépare matière annoncée, épaisseur, diamètre, fermeture et unité de vente. Le tableau des tailles s'ouvre près du bouton d'achat : la question est traitée là où elle apparaît. La navigation par emplacement offre un raccourci aux clientes qui connaissent déjà leur piercing.

### Ce qui peut être amélioré

Le tableau est une image dense, difficile à lire à 390 px. L'aide existe aussi dans un ancien guide, des articles et un nouveau PDF à recevoir par email. Cette dispersion impose plusieurs lectures et rend la mise à jour plus délicate. Les articles alternent pédagogie précise, longs détours et formulations trop assurées.

### À transposer chez Odelina

Conserver le principe de l'aide contextuelle, avec **une question et un schéma adaptés au bijou choisi**. Une table HTML et une liste de mesures restent lisibles et accessibles. L'information essentielle doit être consultable sans email ; un éventuel support imprimable viendra en complément.

La marque annonce aussi un quiz de composition personnalisée et une page Mix and Match. Leur existence est confirmée, leur parcours complet n'a pas été validé. L'opportunité d'Odelina reste de montrer immédiatement ce que le Composer permet d'adapter.

> **Transposer un principe, pas un écran :** rapprocher l'explication du choix, avec les données et les mots propres à Odelina.

*Sources A : [fiche Oser](https://bylesaudacieuses.com/products/piercing-anneau-oser-titane), [guide PDF](https://bylesaudacieuses.com/pages/guide-des-tailles-telecharge-ton-pdf-gratuit), [composition personnalisée](https://bylesaudacieuses.com/pages/compose-ton-oreille-ideale). Observation et ouverture du tableau : 18/10/2026.*

<!-- PAGE -->

## Nébuleuse : montrer le bijou dans son ensemble

### Ce qui fonctionne

La fiche **Andrea Titane** distingue décor, longueur de barre et épaisseur. Le guide de taille s'ouvre dans un tiroir. Les photographies portées rendent le résultat concret avant une longue lecture. La composition **Lumineuse** identifie quatre pièces et leur prix : les inclusions sont compréhensibles.

### Ce qui reste à comprendre pour acheter

Le guide des anneaux associe les zones à des dimensions courantes, mais ne montre pas comment mesurer le diamètre intérieur. La fiche Lumineuse observée ne fournit pas de correspondance explicite « pièce → emplacement → dimension » ni d'adaptation par zone. Cela ne démontre pas l'absence de ces possibilités ailleurs sur le site.

Le guide d'entretien donne des gestes mémorables mais réunit plusieurs matières et types de bijoux. Le public concerné par les consignes de retrait n'est pas toujours explicite. Les promesses absolues de tolérance ne doivent pas être reprises.

### À transposer chez Odelina

Photographier les sets portés, identifier chaque pièce, puis **expliquer l'équilibre de la composition** : point principal, rappel, espace laissé entre deux éléments. Le Composer doit permettre d'en faire sa version avec moins de trous ou une autre pièce.

La fiche du set devra distinguer l'effet esthétique de la validation dimensionnelle. Un nom de zone ou une belle photographie ne confirme pas l'ajustement à l'oreille.

*Sources N : [Andrea](https://nebuleusebijoux.com/products/andrea-titane), [Anneau Léonie et tiroir taille](https://nebuleusebijoux.com/products/anneau-leonie), [composition Lumineuse](https://nebuleusebijoux.com/products/composition-lumineuse), [entretien](https://nebuleusebijoux.com/blogs/blog/prendre-soin-de-ses-bijoux). 18/10/2026.*

<!-- PAGE -->

## Luceat : rapprocher les guides des produits

### Ce qui fonctionne

Les fiches **Lotus** et **Dune** donnent accès aux tailles, aux noms de piercing et à l'entretien dans des accordéons. Le menu rendu propose des liens directs vers les guides. Les inspirations **Flowers** et **Fresh** montrent une association de bijoux et renvoient vers les pièces utilisées.

### Ce qui manque à la décision

Le guide de tailles couvre de nombreuses zones mais réunit longueur et diamètre dans une même colonne, sans méthode illustrée de mesure. Dans la fiche Dune, une dimension d'anneau est appelée longueur : une petite imprécision peut changer le sens d'une commande.

Le guide des emplacements repose essentiellement sur une image sans équivalent textuel détaillé à côté. Le guide d'entretien est court, mais distingue mal l'objet et les soins d'un piercing. Un texte de paramétrage est encore visible dans la FAQ de la collection acier.

### À transposer chez Odelina

Garder les explications à portée de la fiche et du Composer, avec **un vocabulaire exact et un contenu propre à la pièce**. Accompagner la carte d'une liste accessible. Décrire une composition puis offrir sa personnalisation, au lieu de faire reconstruire l'ensemble entre plusieurs fiches.

Les anciennes destinations trouvées dans le HTML initial ont été corrigées par le menu JavaScript rendu : elles ne sont pas retenues comme défaut du parcours normal. C'est un exemple de la différence entre lire du code et observer une interface réellement chargée.

*Sources L : [guide taille](https://luceatpiercing.fr/pages/guide-de-taille), [emplacements](https://luceatpiercing.fr/blogs/infos/guide-des-piercings), [Dune](https://luceatpiercing.fr/products/dune), [Flowers](https://luceatpiercing.fr/products/flowers). 18/10/2026.*

<!-- PAGE -->

## Titanea : la profondeur demande de la cohérence

### Ce qui fonctionne

Le guide explique épaisseur, longueur utile et diamètre intérieur. Son sommaire permet d'aller à une question précise. La fiche **Le Simple** rapproche l'aide du sélecteur de taille et détaille matière, finition, fermeture et emplacements. Les textes d'inspiration donnent un vocabulaire de composition utile.

### La limite du volume

L'accumulation de tableaux, recommandations et pages augmente le coût de maintenance. Le guide donne par exemple des repères différents entre son développement et son tableau final pour le nombril et le daith. Deux articles d'entretien proposent aussi des recettes salines différentes. Ces prescriptions ne sont pas reprises dans nos recommandations.

Le sélecteur produit affiche des couples de chiffres ; une explication de leur sens reste nécessaire. La présence de nombreuses réponses n'empêche donc pas une hésitation au moment du choix.

### À transposer chez Odelina

Conserver la **précision des explications**, avec une réponse courte en premier et des détails accessibles ensuite. Une donnée ne doit pas être ressaisie dans plusieurs pages. La référence technique doit alimenter les variantes, l'aide, le set et le récapitulatif.

Dans l'échantillon étudié, l'inspiration reste éditoriale : aucun outil interactif comparable n'a été validé. Pour Odelina, l'étape supplémentaire sera de rendre la composition modifiable, puis de montrer ce qui a changé dans le choix, le total et les composants nécessaires.

*Sources T : [guide des tailles](https://titanea.fr/guide-des-tailles-des-piercings/), [Le Simple](https://titanea.fr/piercing-en-titane/le-simple/), [entretien](https://titanea.fr/piercing-doreille-guide-nettoyage-entretien/), [compositions](https://titanea.fr/composition-piercing-oreille-le-top-5-des-curated-ear-2026/). 18/10/2026.*

<!-- PAGE -->

## Odelina possède déjà la bonne base

### À conserver

Le site articule déjà **Les Pièces**, **Mises en scène** et **Mes créations**. Le Composer propose onze points, des variantes par emplacement, un choix de taille et une aide intégrée. La source du guide est partagée entre la page complète, les fiches et le Composer : c'est un acquis de cohérence à préserver.

Le langage visuel est calme : Fraunces, Manrope, fonds crème, encre sombre et accents champagne. Il n'y a aucune raison de remplacer cette identité par celle d'un concurrent.

### À corriger en premier

- **La taille :** retirer l'hypothèse « perçage en France = probablement 1,2 mm », le test de la carte bancaire et le choix conseillé en cas de gonflement.
- **La promesse :** le guide annonce une taille préremplie par emplacement, alors que le Composer propose un choix parmi les variantes. Une sélection d'interface n'est pas une recommandation anatomique.
- **Les composants :** distinguer la tête d'embout de sa barre, vendue séparément.
- **Les textes :** harmoniser finitions, conditions de retour et mentions de bijoux non stériles. Décrire les sets par leurs pièces et leur équilibre plutôt que par une accumulation d'abstractions.

### Le chantier différenciant

Les Mises en scène observées renvoient aux fiches des pièces ; elles ne chargent pas directement leur composition dans le Composer. **Créer cette continuité est une proposition, pas une fonctionnalité annoncée comme existante.**

*Sources O : [guide en ligne](https://www.odelina.fr/pages/guide-des-tailles), [Mises en scène](https://www.odelina.fr/pages/mise-en-scene), [Composer](https://www.odelina.fr/pages/mes-creations) ; code au commit 6897d0f. Pages consultées avec l'accès fourni, 18/10/2026.*

<!-- PAGE -->

## Des textes qui aident à voir et à choisir

### La règle éditoriale Odelina

**Une phrase de rendu, une explication utile, puis la donnée vérifiable.** Le style peut évoquer la lumière sans remplacer ce que la cliente doit comprendre. Employer « vous », garder des verbes concrets et les mêmes noms de finition partout.

| À éviter | Direction proposée |
|---|---|
| Une suite de superlatifs sur le luxe ou la perfection. | Décrire la forme, le mouvement ou la manière dont deux pièces se répondent. |
| « Taille : 8 » sans contexte. | « Diamètre intérieur : 8 mm » ou « Longueur utile : 8 mm », selon la pièce. |
| Une compatibilité formulée comme une garantie anatomique. | Expliquer les variantes prévues pour la zone et ce que la cliente doit vérifier. |
| Des garanties absolues de tolérance ou de résistance. | Nommer matière, finition, limites et justificatifs disponibles. |

### Exemple de réécriture : Cascade

**Direction proposée, à confronter aux visuels et aux pièces :** « Cascade joue sur le mouvement. Les éléments mobiles attirent le regard, tandis que les autres pièces laissent respirer l'ensemble. Gardez toute la composition ou un seul détail mobile pour une version plus discrète. »

Cette proposition n'ajoute ni nature de pierre ni emplacement non vérifié. La version finale précisera la pièce principale et les points concernés après validation d'Aurélie.

### Une relecture commune

Relire ensemble fiches, sets, guides et Composer. Contrôler les unités, les liens, les noms des pièces, les inclusions et les exceptions. **La cohérence est une preuve de qualité plus durable qu'une promesse répétée.**

*Sources : textes des Mises en scène en ligne ; canon éditorial et données versionnées Odelina, commit 6897d0f. Règles et réécriture proposées, non publiées.*

<!-- PAGE -->

## Trois pages de service, une même composition

### Tailles — « Quelle mesure dois-je vérifier ? »

Conserver l'URL actuelle et la source éditoriale commune. Commencer par anneau, embout ou barre ; expliquer la mesure correspondante ; montrer comment lire une cote ; orienter vers le perceur si la mesure n'est pas connue. L'aide courte du Composer ouvre sur la bonne question.

### Emplacements — « Où se situe cette zone ? »

Créer une page pérenne avec carte et liste équivalente. Neuf zones anatomiques correspondent aux onze points du Composer parce que le lobe est décliné en 1, 2 et 3. Chaque fiche donne un repère, un rôle dans la composition et la mesure à vérifier. La carte n'est pas un diagnostic de faisabilité.

### Entretien — « Comment préserver ces pièces ? »

Créer une page pérenne, puis ses résumés contextuels. Partir de la pièce complète : base, finition, décor et fermeture. Séparer entretien du bijou et piercing récent ; ne pas prescrire de protocole de plaie. Un set peut renvoyer vers les consignes de ses composants.

> **Le contrat UX commun :** ouvrir l'aide, comprendre une seule question, refermer et retrouver la même composition au même endroit.

Ces pages rejoignent l'aide de la boutique. Elles n'imposent ni nouvel onglet de blog, ni forum, ni programme régulier d'articles. Le bloc Journal déjà présent dans le code des Mises en scène est conditionnel : vérifier sa configuration et éviter sa réapparition future si ce choix reste celui de la marque.

*Sources : structure du thème Odelina, snippets de guide et composants du Composer ; aucune nouvelle route créée. Les pages et liens contextuels décrits sont des propositions.*

<!-- PAGE -->

## L'ordre utile pour passer à l'action

| Étape | Livrable concret | Condition de réussite |
|---|---|---|
| **P0 · corriger** | Guide aligné, finitions et retours cohérents, mesures nommées, conseils trompeurs retirés. | Une même règle dans les quatre points de contact ; validation éditoriale et produit. |
| **P1 · expliquer** | Trois pages permanentes et leurs aides courtes. | Une cliente comprend la mesure ou la zone et revient à son choix sans le perdre. |
| **P1 · différencier** | Un premier set correctement décrit et transférable au Composer. | Pièces, emplacements et variantes définis ; une pièce remplaçable sans recommencer. |
| **P2 · affiner** | Correctifs mobile, focus et clarté des ruptures, selon les tests. | Les parcours fonctionnent aussi au clavier, avec zoom et sur petit écran. |

### Un pilote suffit pour apprendre

Choisir une Mise en scène, documenter ses pièces, puis faire tester cinq tâches : comprendre le set, adapter un emplacement, distinguer décor et barre, consulter l'aide puis revenir, expliquer ce qui sera réellement commandé. Aucun paiement n'est nécessaire pour ce premier test.

Observer les erreurs, les hésitations et l'aide demandée. Le taux de réussite est le nombre de tâches achevées correctement rapporté aux tentatives ; ce ne sera pas un chiffre de conversion. Définir le critère avant le test et conserver les verbatims utiles.

**Aurélie** valide les mots, les photos et les ensembles. **Tony** relie les données et les interactions. Les fournisseurs confirment les mesures, composants et consignes d'entretien ; le perceur relit les limites des conseils de choix. Aucun effort en jours ni bénéfice chiffré n'est promis à ce stade.

*Proposition de déploiement. Les quatre dossiers thématiques détaillent les textes, dépendances, états d'interface et critères de vérification.*

<!-- PAGE -->

## Sources de la veille concurrentielle

**Consultation : 18 octobre 2026.** Sélection des principales pages probantes. Les notes d'audit jointes recensent les autres pages et les limites de chaque contrôle. Liens cliquables dans ce PDF.

### By Les Audacieuses

- [Oser : fiche et tableau de tailles](https://bylesaudacieuses.com/products/piercing-anneau-oser-titane).
- [Nouveau guide PDF](https://bylesaudacieuses.com/pages/guide-des-tailles-telecharge-ton-pdf-gratuit) et [ancien guide](https://bylesaudacieuses.com/pages/guide-des-tailles).
- [Entretien et changement](https://bylesaudacieuses.com/pages/entretien-changement-de-vos-bijoux).
- [Composition personnalisée](https://bylesaudacieuses.com/pages/compose-ton-oreille-ideale) et [Mix and Match](https://bylesaudacieuses.com/pages/collection-bundle) : parcours complets non validés.

### Nébuleuse Bijoux

- [Andrea Titane](https://nebuleusebijoux.com/products/andrea-titane) et [Anneau Léonie](https://nebuleusebijoux.com/products/anneau-leonie).
- [Guide des emplacements](https://nebuleusebijoux.com/blogs/blog/meilleurs-piercings-doreille-le-guide-et-notre-selection).
- [Entretien](https://nebuleusebijoux.com/blogs/blog/prendre-soin-de-ses-bijoux).
- [Sets](https://nebuleusebijoux.com/collections/sets) et [composition Lumineuse](https://nebuleusebijoux.com/products/composition-lumineuse).

### Luceat Piercing

- [Guide de taille](https://luceatpiercing.fr/pages/guide-de-taille), [emplacements](https://luceatpiercing.fr/blogs/infos/guide-des-piercings) et [entretien](https://luceatpiercing.fr/blogs/infos/guide-dentretien).
- [Lotus](https://luceatpiercing.fr/products/lotus), [Dune](https://luceatpiercing.fr/products/dune), [Flowers](https://luceatpiercing.fr/products/flowers) et [Fresh](https://luceatpiercing.fr/products/fresh).

*Les contenus concurrentiels sont reformulés. Leurs promesses matière, santé, prix ou disponibilité sont des déclarations observées, pas des validations indépendantes.*

<!-- PAGE -->

## Sources complémentaires et cadre de fiabilité

### Titanea

- [Guide des tailles](https://titanea.fr/guide-des-tailles-des-piercings/) et [Le Simple](https://titanea.fr/piercing-en-titane/le-simple/).
- [Entretien titane](https://titanea.fr/comment-nettoyer-un-piercing-en-titane-le-guide-complet/) et [entretien oreille et bijou](https://titanea.fr/piercing-doreille-guide-nettoyage-entretien/).
- [Compositions d'oreille](https://titanea.fr/composition-piercing-oreille-le-top-5-des-curated-ear-2026/).

### Odelina — site et code examinés

- [Guide existant](https://www.odelina.fr/pages/guide-des-tailles), [Mises en scène](https://www.odelina.fr/pages/mise-en-scene), [Composer](https://www.odelina.fr/pages/mes-creations).
- [Dépôt, état exact lu](https://github.com/Lykoleen/Odelina/tree/6897d0f74c0d51383a7e15ad6e92d91a4c91503f).
- [Guide partagé](https://github.com/Lykoleen/Odelina/blob/6897d0f74c0d51383a7e15ad6e92d91a4c91503f/snippets/guide-tailles.liquid), [choix de taille](https://github.com/Lykoleen/Odelina/blob/6897d0f74c0d51383a7e15ad6e92d91a4c91503f/composer/src/components/ChoixTaille.jsx), [Mises en scène](https://github.com/Lykoleen/Odelina/blob/6897d0f74c0d51383a7e15ad6e92d91a4c91503f/templates/page.mise-en-scene.json).

### Références professionnelles distinctes des concurrents

- APP : [bijoux pour piercings cicatrisés](https://safepiercing.org/jewelry-for-healed-piercings/) et [matières / adaptation](https://safepiercing.org/jewelry-for-initial-piercings/).
- [ASTM F136-26](https://store.astm.org/f0136-26.html) : fiche de norme matière, sans validation des produits Odelina.
- [NHS : signes d'infection](https://www.nhs.uk/conditions/infected-piercings/) : utilisé pour l'orientation médicale, pas comme routine d'entretien.

Les guides thématiques distinguent les textes proposés, les validations produit et les recommandations internes. Les sources professionnelles peuvent diverger sur certains soins ; aucun faux consensus ni protocole de cicatrisation n'est intégré aux pages proposées.

*Étude privée au 18/10/2026. Le code décrit un état versionné ; le site et ses données peuvent évoluer. Aucun fichier source, thème publié ou réglage commercial n'a été modifié par cette étude.*
