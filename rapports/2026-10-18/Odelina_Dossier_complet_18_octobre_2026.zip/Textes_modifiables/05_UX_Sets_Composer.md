## Faire des sets le début d'une création

**Le cap : comprendre un ensemble, puis se l’approprier.** Odelina possède déjà un Composer dédié, des Mises en scène et une identité calme. L’enjeu est de rendre leur continuité évidente. Les nouvelles pages servent cette expérience : comprendre une taille, reconnaître un emplacement, entretenir ses bijoux. Elles restent des références permanentes, sans blog ni forum à créer.

Luceat montre des associations photographiées et relie les pièces ; Titanea développe le vocabulaire de la composition. Odelina peut transformer cette inspiration en projet modifiable. La valeur se situe dans ce que la cliente peut faire avec un set, et dans la qualité des explications qui accompagnent son choix.

Préserver les acquis : un guide partagé entre page, produit et Composer ; des schémas de dimensions ; des photos portées ; un total calculé ; un récapitulatif avec modification, retrait et partage. Conserver la palette crème et encre, les titres Fraunces et le texte Manrope. Réserver les explications décisives à un corps réellement lisible.

La promesse éditoriale proposée : **« Partez d’une composition qui vous plaît, adaptez-la à vos emplacements et vérifiez chaque pièce avant de commander. »** Le rendu aide à associer des bijoux ; il ne valide ni l’anatomie ni l’ajustement. L’inspiration reste libre, même lorsqu’une pièce est épuisée ; le panier distingue ce qui peut être acheté.

Références : [guide partagé Odelina](https://github.com/Lykoleen/Odelina/blob/6897d0f74c0d51383a7e15ad6e92d91a4c91503f/snippets/guide-tailles.liquid#L1), [identité actuelle](https://github.com/Lykoleen/Odelina/blob/6897d0f74c0d51383a7e15ad6e92d91a4c91503f/snippets/css-variables.liquid#L23), [compositions Luceat](https://luceatpiercing.fr/collections/idee-de-conception), [inspiration Titanea](https://titanea.fr/composition-piercing-oreille-le-top-5-des-curated-ear-2026/). Observation : 18 octobre 2026.

<!-- PAGE -->

## Relier l’inspiration à la composition

**Parcours établi aujourd’hui.** Les Mises en scène présentent des photos, des pièces et leur total. Le code prévoit un retour de la fiche produit au set. Les quatre compositions configurées possèdent cependant un libellé « Voir le set » sans destination : leur bouton principal ne peut pas être rendu par ce composant. Aucun chargement de ces sets dans le Composer n’est établi par cette configuration. Le thème lu ne prouve pas, à lui seul, la version publiée.

Le Composer existe déjà : emplacement → bijou → choix de taille si plusieurs options → composition → récapitulatif. Une taille unique se pose directement. Le lien générique depuis une fiche ne transporte pas explicitement le bijou ; sa contextualisation reste à vérifier en navigation.

**Parcours cible proposé.** Mises en scène → « Personnaliser cette composition » → Composer prérempli → retirer ou remplacer une pièce → confirmer les dimensions → vérifier les composants → ajouter les pièces disponibles. Garder « Voir les pièces » comme accès secondaire.

Cette continuité exige une donnée absente du simple catalogue de set : affectation de chaque bijou à un emplacement, une finition et une variante. Le projet doit signaler une référence indisponible sans substituer silencieusement une pièce. Toute aide ouverte pendant le parcours doit préserver les choix et permettre de reprendre au même endroit.

C’est une évolution à concevoir et tester. Les liens partagés existants constituent une base technique à examiner, sans promettre qu’ils suffisent à construire des liens marchands durables.

Références : [sets configurés](https://github.com/Lykoleen/Odelina/blob/6897d0f74c0d51383a7e15ad6e92d91a4c91503f/templates/page.mise-en-scene.json#L143), [condition du bouton](https://github.com/Lykoleen/Odelina/blob/6897d0f74c0d51383a7e15ad6e92d91a4c91503f/sections/stacks.liquid#L173), [choix de taille](https://github.com/Lykoleen/Odelina/blob/6897d0f74c0d51383a7e15ad6e92d91a4c91503f/composer/src/components/ChoixTaille.jsx#L1).

<!-- PAGE -->

## Une fiche set qui explique son équilibre

La fiche set doit répondre à trois questions avant toute longue explication : **qu’est-ce qui compose cet ensemble, pourquoi les pièces vont-elles ensemble, que puis-je adapter ?** Garder une photographie dominante, un texte court et un accès clair au Composer. Éviter l’accumulation de badges et d’adjectifs abstraits.

Ordre proposé : nom ; photographie et finition montrée ; description de 40 à 70 mots ; liste des pièces avec visuel, unité de vente, finition, dimensions et disponibilité ; total correspondant à cette sélection ; bouton « Personnaliser cette composition ». Les emplacements affichés doivent venir d’une affectation validée, pas d’une déduction automatique de la photographie. Une barre séparée reste explicitement séparée.

**Modèle éditorial :** une phrase décrit les formes et leur emplacement observé ; une autre explique le lien visuel ; la dernière ouvre une adaptation concrète. Aucun nom de pierre ou matériau secondaire n’est déduit d’une image.

**Exemple « En fleurs », fondé sur le texte versionné, à vérifier avec le visuel et les références :**

> En fleurs associe une grappe près de l’hélix, un anneau au daith et des pièces au lobe. Le titane naturel donne une continuité à l’ensemble. Gardez cette association comme point de départ, puis adaptez le nombre de pièces à vos emplacements déjà percés. Les tailles restent à vérifier pour chaque bijou.

Le titre du bouton ne doit pas annoncer une remise : le projet ne prévoit pas de réduction de set au MVP. Le prix présenté reste la somme des pièces effectivement retenues.

Références : [En fleurs et ses références](https://github.com/Lykoleen/Odelina/blob/6897d0f74c0d51383a7e15ad6e92d91a4c91503f/templates/page.mise-en-scene.json#L202), [calcul et présentation des pièces](https://github.com/Lykoleen/Odelina/blob/6897d0f74c0d51383a7e15ad6e92d91a4c91503f/sections/stacks.liquid#L21), [contraintes du projet](https://github.com/Lykoleen/Odelina/blob/6897d0f74c0d51383a7e15ad6e92d91a4c91503f/Contexte-projet.md#L137).

<!-- PAGE -->

## Mobile et accessibilité : consolider les acquis

Le code Odelina prévoit déjà des cibles de marqueurs de 44 pixels, des boutons nommés, des états sélectionnés, une liste d’emplacements et des styles de focus. Les fenêtres de taille et de guide utilisent des dialogues natifs. La réduction des animations et les espaces de sécurité iOS sont également pris en compte. Ces bases doivent être préservées.

**Le contrôle prioritaire concerne les transitions.** Depuis un bijou, ouvrir la taille puis le guide, fermer le guide, retrouver son choix et poursuivre. Le clavier doit rester dans la fenêtre active et revenir à la commande d’origine à sa fermeture. Le récapitulatif se déclare modal dans le code, mais sa gestion complète du focus n’a pas été repérée : c’est un risque à tester au navigateur, pas une non-conformité WCAG mesurée.

Sur 360 et 390 pixels, vérifier que le guide reste lisible sans faire perdre la position dans la composition. À 200 % de zoom, contrôler les points proches, les commandes fixes et le défilement. L’alternative textuelle doit permettre de choisir un emplacement sans viser une petite zone de l’image. Les ruptures et incompatibilités doivent rester compréhensibles sans dépendre de la couleur.

Conserver une action principale lisible et une aide secondaire discrète. Préserver aussi la décision d’éviter un second aperçu d’oreille dans le récapitulatif mobile. Les explications de mesure essentielles ne doivent pas être reléguées dans les plus petits corps typographiques.

Références : [marqueurs](https://github.com/Lykoleen/Odelina/blob/6897d0f74c0d51383a7e15ad6e92d91a4c91503f/composer/src/components/Oreille.jsx#L128), [récapitulatif](https://github.com/Lykoleen/Odelina/blob/6897d0f74c0d51383a7e15ad6e92d91a4c91503f/composer/src/components/Recap.jsx#L49), [styles et focus](https://github.com/Lykoleen/Odelina/blob/6897d0f74c0d51383a7e15ad6e92d91a4c91503f/composer/src/styles.css#L753).

<!-- PAGE -->

## Des microtextes qui évitent les mauvaises surprises

Propositions à relier au catalogue, sans changer les décisions existantes : ruptures essayables, compte pour enregistrer, partage libre, barre séparée.

**État vide.** « Choisissez un emplacement déjà percé pour commencer votre composition. » Conserver les boutons existants « Commencer par Lobe 1 », « Commencer par Hélix », « Commencer par Conch ».

**Taille.** Anneau : « Diamètre intérieur ». Barre courbée : « Longueur utile — voir le schéma ». Embout : « Dimensions de la tête — ce n’est pas la longueur de la barre ». Aide : « Taille inconnue ? Faites-la vérifier par votre perceur. » Taille unique : « Une dimension proposée pour ce modèle ; vérifiez qu’elle vous convient. » Hint : « Choisissez la taille avant de poser le bijou lorsqu’il existe plusieurs options. »

**Rupture.** « Épuisé : vous pouvez l’essayer dans votre composition. Il ne sera pas ajouté au panier. » Récapitulatif : « Ajouter les {n} bijoux disponibles — {montant} ». Distinguer ce montant du total incluant les pièces essayées.

**Embout et barre.** « Embout seul. Barre vendue séparément. » Puis « Vérifier la barre et le système de fixation ». Aucune compatibilité universelle entre marques n’est promise.

**Partage et compte.** « Copier le lien de partage » ; confirmation « Lien copié ». « Enregistrer dans mon compte » ; explication « Connectez-vous pour retrouver vos compositions sur vos appareils. Le partage par lien reste accessible sans compte. » Échec : « L’enregistrement n’a pas abouti. Réessayez ou copiez le lien de partage. »

Références : [états et actions du récapitulatif](https://github.com/Lykoleen/Odelina/blob/6897d0f74c0d51383a7e15ad6e92d91a4c91503f/composer/src/components/Recap.jsx#L101), [questions dimensionnelles](https://github.com/Lykoleen/Odelina/blob/6897d0f74c0d51383a7e15ad6e92d91a4c91503f/composer/src/components/ChoixTaille.jsx#L20), [embouts seuls](https://github.com/Lykoleen/Odelina/blob/6897d0f74c0d51383a7e15ad6e92d91a4c91503f/sections/product.liquid#L438).

<!-- PAGE -->

## Une feuille de route centrée sur l’usage

Les efforts ci-dessous sont relatifs ; ils expriment la complexité, sans calendrier, budget ou gain de conversion inventé. **Un blocage d’accès ou de commande confirmé devient prioritaire**, quel que soit son classement initial.

**P0 — fiabilité et cohérence éditoriale. Effort faible à moyen.** Corriger les fausses certitudes sur la jauge, le test visuel de carte bancaire et la réponse au gonflement. Aligner le guide, les hints et les libellés sur le choix réel des tailles. Harmoniser la finition dorée, l’embout seul et les conditions de retour. Dépendances : relecture métier, caractéristiques fournisseur, validation de la formulation commerciale. Contrôler le risque de focus du récapitulatif ; toute impossibilité d’usage confirmée se traite immédiatement.

**P1 — continuité sets et Composer. Effort moyen à élevé.** Définir l’affectation des pièces et variantes de chaque set. Concevoir puis tester « Personnaliser cette composition », la conservation des choix et l’état de rupture. Réécrire les textes de sets et publier les trois pages permanentes avec aide contextuelle. Dépendances : catalogue fiable, conventions de dimensions et validation des emplacements ; les consignes d’entretien attendent la validation fournisseur.

**P2 — perfectionnement après observation. Effort variable.** Affiner la lecture mobile, les explications de total et la transition fiche produit → Composer selon les tests. Conserver l’enregistrement dans le compte et le partage existants ; ne pas créer une nouvelle wishlist. Aucune refonte de marque, 3D, galerie publique ou photo d’oreille à téléverser n’est nécessaire pour ce programme.

Une première vérification qualitative précède chaque élargissement : comprendre les difficultés évite de multiplier les fonctions et les textes.

Références : [guide à corriger](https://github.com/Lykoleen/Odelina/blob/6897d0f74c0d51383a7e15ad6e92d91a4c91503f/snippets/guide-tailles.liquid#L42), [périmètre MVP](https://github.com/Lykoleen/Odelina/blob/6897d0f74c0d51383a7e15ad6e92d91a4c91503f/Contexte-projet.md#L309), [principes de dimensionnement APP](https://safepiercing.org/jewelry-for-healed-piercings/).

<!-- PAGE -->

## Vérifier que l’expérience reste simple

Mener une première série avec cinq à huit personnes, comprenant des clientes peu familières des noms d’emplacements et des utilisatrices régulières de bijoux. Ce petit échantillon révèle des difficultés ; il ne mesure pas un effet commercial représentatif. Tester l’existant comme référence, puis le prototype avec des scénarios comparables. Annoncer à l’avance les critères de réussite ; ne pas guider pendant la tâche.

**Cinq tâches :**

1. Retrouver sur l’oreille une zone montrée en photo et sélectionner cet emplacement sans connaître son nom.
2. Partir d’« En fleurs », retirer une pièce puis en remplacer une autre, en conservant les autres choix.
3. Expliquer la différence entre épaisseur, longueur de barre et dimensions d’embout ; ouvrir l’aide puis reprendre le choix de taille.
4. Vérifier une composition contenant un embout seul et une pièce épuisée ; annoncer exactement ce qui sera acheté et ce qui manque.
5. Copier un lien sans compte, puis expliquer ce que change l’enregistrement dans le compte. Utiliser un environnement de test pour toute connexion ou action panier.

**Indicateurs définis :** réussite sans aide par tâche ; nombre d’interventions nécessaires ; durée jusqu’au résultat ; erreurs de dimensions ou de composants ; perte de choix après ouverture de l’aide ; correspondance entre contenu annoncé et panier obtenu. Pour chaque mesure, conserver le numérateur, le dénominateur et les abandons. Une difficulté récurrente appelle une modification, puis une nouvelle vérification ciblée.

Compléter par un parcours clavier, lecteur d’écran, zoom et téléphone. Aucun gain ni résultat utilisateur n’est revendiqué ici : ce document prépare le protocole.

Références : [liste et repères du Composer](https://github.com/Lykoleen/Odelina/blob/6897d0f74c0d51383a7e15ad6e92d91a4c91503f/composer/src/components/Oreille.jsx#L128), [règles du récapitulatif](https://github.com/Lykoleen/Odelina/blob/6897d0f74c0d51383a7e15ad6e92d91a4c91503f/composer/src/components/Recap.jsx#L140), [parcours live observé](https://www.odelina.fr/pages/mes-creations).
